import { useEffect, useRef, useState } from 'react';
import { TrendingUp, PieChart, Zap, Bitcoin } from 'lucide-react';

const Products = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [activeTab, setActiveTab] = useState(0);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const tabs = [
    {
      id: 'stocks',
      label: 'Stock Trading',
      icon: TrendingUp,
      title: 'Trade Stocks with Confidence',
      description: 'Access thousands of stocks with real-time data, advanced charting, and instant execution. Invest in companies you believe in.',
      features: ['Real-time quotes', 'Advanced order types', 'Fractional shares'],
    },
    {
      id: 'etfs',
      label: 'ETF Investing',
      icon: PieChart,
      title: 'Diversify with ETFs',
      description: 'Build a diversified portfolio with exchange-traded funds. Low-cost access to entire markets and sectors.',
      features: ['Broad market exposure', 'Low expense ratios', 'Instant diversification'],
    },
    {
      id: 'options',
      label: 'Options',
      icon: Zap,
      title: 'Advanced Options Trading',
      description: 'Take your trading to the next level with options strategies. Hedge your portfolio or generate income.',
      features: ['Multi-leg strategies', 'Risk analysis tools', 'Educational resources'],
    },
    {
      id: 'crypto',
      label: 'Crypto',
      icon: Bitcoin,
      title: 'Trade Cryptocurrency',
      description: 'Buy, sell, and hold popular cryptocurrencies alongside your traditional investments.',
      features: ['Major cryptocurrencies', 'Secure cold storage', '24/7 trading'],
    },
  ];

  return (
    <section 
      ref={sectionRef}
      className="py-24 bg-[#fafafa]"
    >
      <div className="max-w-[1400px] mx-auto px-5">
        {/* Section Header */}
        <div 
          className="text-center mb-16"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(40px)',
            transition: 'all 0.7s var(--ease-expo-out)',
          }}
        >
          <span className="inline-block px-4 py-2 bg-[#ffba07]/20 text-[#ffba07] rounded-full text-sm font-semibold mb-4">
            Our Products
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-['Poppins'] text-[#333] mb-4">
            All Your <span className="text-gradient">Investments</span> in One Place
          </h2>
          <p className="text-lg text-[#666] max-w-2xl mx-auto">
            From stocks to crypto, trade everything you need to build your portfolio
          </p>
        </div>

        <div className="grid lg:grid-cols-12 gap-8 lg:gap-12">
          {/* Tabs - Left Side */}
          <div 
            className="lg:col-span-4 space-y-3"
            style={{
              opacity: isVisible ? 1 : 0,
              transform: isVisible ? 'translateX(0)' : 'translateX(-50px)',
              transition: 'all 0.6s var(--ease-expo-out)',
            }}
          >
            {tabs.map((tab, index) => {
              const Icon = tab.icon;
              const isActive = activeTab === index;
              
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(index)}
                  className={`w-full flex items-center gap-4 p-4 rounded-2xl text-left transition-all duration-300 relative overflow-hidden ${
                    isActive 
                      ? 'bg-white shadow-lg border-2 border-[#2e68ff]' 
                      : 'bg-transparent border-2 border-transparent hover:bg-white/50 hover:translate-x-2'
                  }`}
                  style={{
                    opacity: isVisible ? 1 : 0,
                    transform: isVisible ? 'translateX(0)' : 'translateX(-20px)',
                    transition: `all 0.4s var(--ease-expo-out) ${100 + index * 80}ms`,
                  }}
                >
                  {/* Active Indicator */}
                  {isActive && (
                    <div 
                      className="absolute left-0 top-0 bottom-0 w-1 bg-[#2e68ff]"
                      style={{ animation: 'slide-in 0.3s var(--ease-expo-out)' }}
                    />
                  )}
                  
                  <div className={`w-12 h-12 rounded-xl flex items-center justify-center transition-all duration-300 ${
                    isActive ? 'bg-gradient-primary' : 'bg-[#e2e2e2]'
                  }`}>
                    <Icon className={`w-6 h-6 transition-colors duration-300 ${
                      isActive ? 'text-white' : 'text-[#666]'
                    }`} />
                  </div>
                  
                  <div>
                    <h3 className={`font-semibold font-['Poppins'] transition-colors duration-300 ${
                      isActive ? 'text-[#2e68ff]' : 'text-[#333]'
                    }`}>
                      {tab.label}
                    </h3>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Content - Right Side */}
          <div 
            className="lg:col-span-8"
            style={{
              opacity: isVisible ? 1 : 0,
              transform: isVisible ? 'rotateY(0)' : 'rotateY(-20deg)',
              transition: 'all 0.8s var(--ease-expo-out) 300ms',
            }}
          >
            <div className="relative bg-white rounded-3xl p-8 lg:p-10 shadow-xl border border-[#e2e2e2] overflow-hidden">
              {/* Content */}
              <div 
                key={activeTab}
                className="space-y-6"
                style={{ animation: 'fade-in-right 0.4s var(--ease-expo-out)' }}
              >
                <h3 className="text-2xl lg:text-3xl font-bold font-['Poppins'] text-[#333]">
                  {tabs[activeTab].title}
                </h3>
                
                <p className="text-lg text-[#666] leading-relaxed">
                  {tabs[activeTab].description}
                </p>

                {/* Features */}
                <div className="flex flex-wrap gap-3">
                  {tabs[activeTab].features.map((feature, index) => (
                    <span 
                      key={index}
                      className="px-4 py-2 bg-[#f7f7f7] rounded-full text-sm font-medium text-[#333]"
                    >
                      {feature}
                    </span>
                  ))}
                </div>

                {/* Image */}
                <div className="relative mt-8">
                  <img
                    src="/tab-feature.jpg"
                    alt={tabs[activeTab].title}
                    className="w-full rounded-2xl shadow-lg"
                    style={{ animation: '3d-reveal 0.4s var(--ease-expo-out)' }}
                  />
                  
                  {/* Floating Stats Card */}
                  <div 
                    className="absolute -bottom-4 -right-4 lg:bottom-8 lg:right-8 w-40 animate-float"
                  >
                    <img
                      src="/stats-card.jpg"
                      alt="Stats"
                      className="w-full rounded-xl shadow-xl"
                      style={{
                        opacity: isVisible ? 1 : 0,
                        transform: isVisible ? 'translateY(0) scale(1)' : 'translateY(50px) scale(0.8)',
                        transition: 'all 0.6s var(--ease-spring) 600ms',
                      }}
                    />
                  </div>
                </div>
              </div>

              {/* Decorative background */}
              <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-bl from-[#2e68ff]/5 to-transparent rounded-full transform translate-x-32 -translate-y-32" />
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes slide-in {
          from {
            transform: scaleY(0);
          }
          to {
            transform: scaleY(1);
          }
        }
        @keyframes fade-in-right {
          from {
            opacity: 0;
            transform: translateX(20px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }
        @keyframes 3d-reveal {
          from {
            opacity: 0;
            transform: rotateY(-15deg);
          }
          to {
            opacity: 1;
            transform: rotateY(0);
          }
        }
      `}</style>
    </section>
  );
};

export default Products;
