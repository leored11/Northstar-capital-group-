import { useEffect, useRef, useState } from 'react';
import { TrendingUp, TrendingDown, DollarSign, PieChart, Activity, ArrowUpRight, ArrowDownRight } from 'lucide-react';

const InvestmentDashboard = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [selectedTimeRange, setSelectedTimeRange] = useState('1D');
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const timeRanges = ['1D', '1W', '1M', '3M', '1Y', 'ALL'];

  const portfolioData = {
    totalValue: 124532.89,
    totalReturn: 18432.56,
    returnPercentage: 17.38,
    dayChange: 1234.56,
    dayChangePercentage: 1.02,
  };

  const holdings = [
    { symbol: 'AAPL', name: 'Apple Inc.', shares: 150, price: 178.35, change: 2.34, value: 26752.50 },
    { symbol: 'MSFT', name: 'Microsoft Corp.', shares: 85, price: 378.91, change: -1.23, value: 32207.35 },
    { symbol: 'GOOGL', name: 'Alphabet Inc.', shares: 120, price: 141.80, change: 3.45, value: 17016.00 },
    { symbol: 'AMZN', name: 'Amazon.com', shares: 200, price: 178.15, change: 0.89, value: 35630.00 },
    { symbol: 'TSLA', name: 'Tesla Inc.', shares: 75, price: 248.42, change: -2.15, value: 18631.50 },
  ];

  const chartData = [
    { time: '9:30', value: 123200 },
    { time: '10:00', value: 123450 },
    { time: '10:30', value: 123100 },
    { time: '11:00', value: 123800 },
    { time: '11:30', value: 124100 },
    { time: '12:00', value: 123950 },
    { time: '12:30', value: 124200 },
    { time: '1:00', value: 124350 },
    { time: '1:30', value: 124150 },
    { time: '2:00', value: 124450 },
    { time: '2:30', value: 124300 },
    { time: '3:00', value: 124532 },
  ];

  const maxValue = Math.max(...chartData.map(d => d.value));
  const minValue = Math.min(...chartData.map(d => d.value));

  return (
    <section 
      id="dashboard"
      ref={sectionRef}
      className="py-24 bg-[#fafafa]"
    >
      <div className="max-w-[1400px] mx-auto px-5">
        {/* Section Header */}
        <div 
          className="text-center mb-16"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(40px)',
            transition: 'all 0.7s var(--ease-expo-out)',
          }}
        >
          <span className="inline-block px-4 py-2 bg-[#ffba07]/20 text-[#ffba07] rounded-full text-sm font-semibold mb-4">
            Platform Preview
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-['Poppins'] text-[#333] mb-4">
            Your Investment <span className="text-gradient">Dashboard</span>
          </h2>
          <p className="text-lg text-[#666] max-w-2xl mx-auto">
            Track your portfolio performance in real-time with professional-grade tools
          </p>
        </div>

        {/* Dashboard Preview */}
        <div 
          className="bg-white rounded-3xl shadow-2xl border border-[#e2e2e2] overflow-hidden"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(40px)',
            transition: 'all 0.8s var(--ease-expo-out) 200ms',
          }}
        >
          {/* Dashboard Header */}
          <div className="bg-gradient-to-r from-[#2e68ff] to-[#0032b3] p-6 text-white">
            <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
              <div>
                <p className="text-white/70 text-sm mb-1">Total Portfolio Value</p>
                <div className="flex items-baseline gap-3">
                  <h3 className="text-3xl lg:text-4xl font-bold font-['Poppins']">
                    ${portfolioData.totalValue.toLocaleString()}
                  </h3>
                  <div className={`flex items-center gap-1 text-sm ${portfolioData.dayChange >= 0 ? 'text-[#10b981]' : 'text-[#ef4444]'}`}>
                    {portfolioData.dayChange >= 0 ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
                    <span>${Math.abs(portfolioData.dayChange).toLocaleString()} ({portfolioData.dayChangePercentage}%)</span>
                  </div>
                </div>
              </div>
              
              {/* Time Range Selector */}
              <div className="flex gap-2">
                {timeRanges.map((range) => (
                  <button
                    key={range}
                    onClick={() => setSelectedTimeRange(range)}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-300 ${
                      selectedTimeRange === range
                        ? 'bg-white text-[#2e68ff]'
                        : 'bg-white/20 text-white hover:bg-white/30'
                    }`}
                  >
                    {range}
                  </button>
                ))}
              </div>
            </div>
          </div>

          <div className="grid lg:grid-cols-3">
            {/* Chart Area */}
            <div className="lg:col-span-2 p-6 border-b lg:border-b-0 lg:border-r border-[#e2e2e2]">
              <div className="flex items-center justify-between mb-6">
                <h4 className="font-semibold text-[#333]">Portfolio Performance</h4>
                <div className="flex items-center gap-2 text-sm">
                  <span className="text-[#666]">Total Return:</span>
                  <span className="text-[#10b981] font-semibold">+${portfolioData.totalReturn.toLocaleString()} ({portfolioData.returnPercentage}%)</span>
                </div>
              </div>

              {/* Chart */}
              <div className="h-64 relative">
                <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                  {/* Gradient definition */}
                  <defs>
                    <linearGradient id="chartGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#2e68ff" stopOpacity="0.3" />
                      <stop offset="100%" stopColor="#2e68ff" stopOpacity="0" />
                    </linearGradient>
                  </defs>
                  
                  {/* Area fill */}
                  <path
                    d={`M 0 ${100 - ((chartData[0].value - minValue) / (maxValue - minValue)) * 80 - 10} ${chartData.map((d, i) => 
                      `L ${(i / (chartData.length - 1)) * 100} ${100 - ((d.value - minValue) / (maxValue - minValue)) * 80 - 10}`
                    ).join(' ')} L 100 100 L 0 100 Z`}
                    fill="url(#chartGradient)"
                  />
                  
                  {/* Line */}
                  <path
                    d={`M 0 ${100 - ((chartData[0].value - minValue) / (maxValue - minValue)) * 80 - 10} ${chartData.map((d, i) => 
                      `L ${(i / (chartData.length - 1)) * 100} ${100 - ((d.value - minValue) / (maxValue - minValue)) * 80 - 10}`
                    ).join(' ')}`}
                    fill="none"
                    stroke="#2e68ff"
                    strokeWidth="0.5"
                  />
                  
                  {/* Data points */}
                  {chartData.map((d, i) => (
                    <circle
                      key={i}
                      cx={(i / (chartData.length - 1)) * 100}
                      cy={100 - ((d.value - minValue) / (maxValue - minValue)) * 80 - 10}
                      r="1"
                      fill="#2e68ff"
                    />
                  ))}
                </svg>

                {/* X-axis labels */}
                <div className="flex justify-between text-xs text-[#999] mt-2">
                  {chartData.filter((_, i) => i % 2 === 0).map((d, i) => (
                    <span key={i}>{d.time}</span>
                  ))}
                </div>
              </div>
            </div>

            {/* Holdings List */}
            <div className="p-6">
              <h4 className="font-semibold text-[#333] mb-4">Your Holdings</h4>
              <div className="space-y-3 max-h-80 overflow-y-auto">
                {holdings.map((stock, index) => (
                  <div 
                    key={index}
                    className="flex items-center justify-between p-3 rounded-xl bg-[#f7f7f7] hover:bg-[#f0f0f0] transition-colors"
                  >
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-lg bg-gradient-primary flex items-center justify-center">
                        <span className="text-white font-bold text-xs">{stock.symbol.slice(0, 2)}</span>
                      </div>
                      <div>
                        <p className="font-semibold text-[#333] text-sm">{stock.symbol}</p>
                        <p className="text-xs text-[#999]">{stock.shares} shares</p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p className="font-semibold text-[#333] text-sm">${stock.value.toLocaleString()}</p>
                      <p className={`text-xs flex items-center justify-end gap-1 ${stock.change >= 0 ? 'text-[#10b981]' : 'text-[#ef4444]'}`}>
                        {stock.change >= 0 ? <TrendingUp className="w-3 h-3" /> : <TrendingDown className="w-3 h-3" />}
                        {stock.change}%
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* Dashboard Stats */}
          <div className="grid grid-cols-2 lg:grid-cols-4 border-t border-[#e2e2e2]">
            {[
              { icon: DollarSign, label: 'Cash Available', value: '$12,450.00' },
              { icon: PieChart, label: 'Diversification', value: '5 Sectors' },
              { icon: Activity, label: 'Day Trades', value: '0/3' },
              { icon: TrendingUp, label: 'Buying Power', value: '$36,982.89' },
            ].map((stat, index) => {
              const Icon = stat.icon;
              return (
                <div 
                  key={index}
                  className={`p-4 flex items-center gap-3 ${index < 3 ? 'border-r border-[#e2e2e2]' : ''} ${index >= 2 ? 'border-t lg:border-t-0' : ''}`}
                >
                  <div className="w-10 h-10 rounded-xl bg-[#2e68ff]/10 flex items-center justify-center">
                    <Icon className="w-5 h-5 text-[#2e68ff]" />
                  </div>
                  <div>
                    <p className="text-xs text-[#999]">{stat.label}</p>
                    <p className="font-semibold text-[#333]">{stat.value}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* CTA */}
        <div 
          className="text-center mt-10"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(20px)',
            transition: 'all 0.6s var(--ease-expo-out) 600ms',
          }}
        >
          <a 
            href="#cta"
            className="inline-flex items-center gap-2 px-8 py-4 bg-[#2e68ff] hover:bg-[#0032b3] text-white rounded-full font-semibold transition-all duration-300 hover:scale-105 hover:shadow-xl"
          >
            Create Your Free Account
            <TrendingUp className="w-5 h-5" />
          </a>
        </div>
      </div>
    </section>
  );
};

export default InvestmentDashboard;
