import { useEffect, useRef, useState } from 'react';
import { UserPlus, Wallet, TrendingUp, BarChart3, CheckCircle2 } from 'lucide-react';

const HowToInvest = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [activeStep, setActiveStep] = useState(0);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const steps = [
    {
      icon: UserPlus,
      title: 'Create Your Account',
      description: 'Sign up in minutes with your email. Complete our secure KYC verification process to unlock full platform access.',
      details: [
        'Quick 5-minute signup process',
        'Secure identity verification',
        'Bank-level encryption',
        'Instant account approval',
      ],
    },
    {
      icon: Wallet,
      title: 'Fund Your Account',
      description: 'Link your bank account and deposit funds. Start with as little as $10. No minimum balance required.',
      details: [
        'Multiple funding options',
        'Instant bank transfers',
        'Recurring deposits available',
        'No deposit fees',
      ],
    },
    {
      icon: TrendingUp,
      title: 'Choose Investments',
      description: 'Browse thousands of stocks, ETFs, options, and cryptocurrencies. Use our research tools to make informed decisions.',
      details: [
        '10,000+ stocks & ETFs',
        'Real-time market data',
        'Expert research reports',
        'Customizable watchlists',
      ],
    },
    {
      icon: BarChart3,
      title: 'Track & Grow',
      description: 'Monitor your portfolio performance in real-time. Set alerts, automate investments, and watch your wealth grow.',
      details: [
        'Real-time portfolio tracking',
        'Performance analytics',
        'Dividend reinvestment',
        'Tax optimization tools',
      ],
    },
  ];

  return (
    <section 
      id="how-to-invest"
      ref={sectionRef}
      className="py-24 bg-white"
    >
      <div className="max-w-[1400px] mx-auto px-5">
        {/* Section Header */}
        <div 
          className="text-center mb-16"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(40px)',
            transition: 'all 0.7s var(--ease-expo-out)',
          }}
        >
          <span className="inline-block px-4 py-2 bg-[#2e68ff]/10 text-[#2e68ff] rounded-full text-sm font-semibold mb-4">
            Getting Started
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-['Poppins'] text-[#333] mb-4">
            How to <span className="text-gradient">Start Investing</span>
          </h2>
          <p className="text-lg text-[#666] max-w-2xl mx-auto">
            Begin your investment journey in four simple steps
          </p>
        </div>

        {/* Steps */}
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Left - Step List */}
          <div className="space-y-4">
            {steps.map((step, index) => {
              const Icon = step.icon;
              const isActive = activeStep === index;
              
              return (
                <div
                  key={index}
                  onClick={() => setActiveStep(index)}
                  className={`cursor-pointer rounded-2xl p-6 border-2 transition-all duration-300 ${
                    isActive 
                      ? 'bg-[#f7f7f7] border-[#2e68ff]' 
                      : 'bg-white border-[#e2e2e2] hover:border-[#2e68ff]/50'
                  }`}
                  style={{
                    opacity: isVisible ? 1 : 0,
                    transform: isVisible ? 'translateX(0)' : 'translateX(-30px)',
                    transition: `all 0.5s var(--ease-expo-out) ${200 + index * 100}ms`,
                  }}
                >
                  <div className="flex items-start gap-4">
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 transition-all duration-300 ${
                      isActive ? 'bg-gradient-primary' : 'bg-[#f7f7f7]'
                    }`}>
                      <Icon className={`w-6 h-6 transition-colors ${
                        isActive ? 'text-white' : 'text-[#666]'
                      }`} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <span className={`text-sm font-semibold ${
                          isActive ? 'text-[#2e68ff]' : 'text-[#999]'
                        }`}>
                          Step {index + 1}
                        </span>
                      </div>
                      <h3 className={`text-lg font-bold font-['Poppins'] mb-2 ${
                        isActive ? 'text-[#2e68ff]' : 'text-[#333]'
                      }`}>
                        {step.title}
                      </h3>
                      <p className="text-[#666] text-sm leading-relaxed">
                        {step.description}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Right - Active Step Details */}
          <div 
            className="lg:sticky lg:top-32"
            style={{
              opacity: isVisible ? 1 : 0,
              transform: isVisible ? 'translateY(0)' : 'translateY(30px)',
              transition: 'all 0.6s var(--ease-expo-out) 400ms',
            }}
          >
            <div className="bg-gradient-to-br from-[#2e68ff] to-[#0032b3] rounded-3xl p-8 text-white">
              <div className="flex items-center gap-4 mb-6">
                <div className="w-16 h-16 rounded-2xl bg-white/20 flex items-center justify-center">
                  {(() => {
                    const Icon = steps[activeStep].icon;
                    return <Icon className="w-8 h-8 text-white" />;
                  })()}
                </div>
                <div>
                  <p className="text-white/70 text-sm">Step {activeStep + 1} of 4</p>
                  <h3 className="text-2xl font-bold font-['Poppins']">
                    {steps[activeStep].title}
                  </h3>
                </div>
              </div>

              <p className="text-white/80 leading-relaxed mb-8">
                {steps[activeStep].description}
              </p>

              <div className="space-y-3">
                {steps[activeStep].details.map((detail, index) => (
                  <div 
                    key={index}
                    className="flex items-center gap-3"
                    style={{
                      animation: `fade-in-right 0.3s var(--ease-expo-out) ${index * 100}ms both`,
                    }}
                  >
                    <CheckCircle2 className="w-5 h-5 text-[#ffba07] flex-shrink-0" />
                    <span className="text-white/90">{detail}</span>
                  </div>
                ))}
              </div>

              {/* Progress Bar */}
              <div className="mt-8 pt-6 border-t border-white/20">
                <div className="flex justify-between text-sm text-white/70 mb-2">
                  <span>Progress</span>
                  <span>{((activeStep + 1) / 4) * 100}%</span>
                </div>
                <div className="h-2 bg-white/20 rounded-full overflow-hidden">
                  <div 
                    className="h-full bg-[#ffba07] rounded-full transition-all duration-500"
                    style={{ width: `${((activeStep + 1) / 4) * 100}%` }}
                  />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes fade-in-right {
          from {
            opacity: 0;
            transform: translateX(-10px);
          }
          to {
            opacity: 1;
            transform: translateX(0);
          }
        }
      `}</style>
    </section>
  );
};

export default HowToInvest;
