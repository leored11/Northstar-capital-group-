import { useEffect, useRef, useState } from 'react';
import { Mail, Phone, MapPin, Send, CheckCircle2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';

const Contact = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: '',
  });
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitted(true);
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({ name: '', email: '', phone: '', subject: '', message: '' });
    }, 3000);
  };

  const contactInfo = [
    {
      icon: Mail,
      title: 'Email Us',
      details: ['support@northstarcapital.com', 'invest@northstarcapital.com'],
    },
    {
      icon: Phone,
      title: 'Call Us',
      details: ['+1 (888) 555-0123', 'Mon-Fri 9am-6pm EST'],
    },
    {
      icon: MapPin,
      title: 'Visit Us',
      details: ['350 Park Avenue', 'New York, NY 10022'],
    },
  ];

  return (
    <section 
      id="contact"
      ref={sectionRef}
      className="py-24 bg-[#fafafa]"
    >
      <div className="max-w-[1400px] mx-auto px-5">
        {/* Section Header */}
        <div 
          className="text-center mb-16"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(40px)',
            transition: 'all 0.7s var(--ease-expo-out)',
          }}
        >
          <span className="inline-block px-4 py-2 bg-[#ffba07]/20 text-[#ffba07] rounded-full text-sm font-semibold mb-4">
            Get in Touch
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-['Poppins'] text-[#333] mb-4">
            Contact <span className="text-gradient">Us</span>
          </h2>
          <p className="text-lg text-[#666] max-w-2xl mx-auto">
            Have questions? We\'re here to help. Reach out to our team.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Contact Info Cards */}
          <div className="space-y-4">
            {contactInfo.map((info, index) => {
              const Icon = info.icon;
              return (
                <div
                  key={index}
                  className="bg-white rounded-2xl p-6 border border-[#e2e2e2] hover:shadow-lg hover:border-[#2e68ff] transition-all duration-300"
                  style={{
                    opacity: isVisible ? 1 : 0,
                    transform: isVisible ? 'translateX(0)' : 'translateX(-30px)',
                    transition: `all 0.5s var(--ease-expo-out) ${200 + index * 100}ms`,
                  }}
                >
                  <div className="w-12 h-12 rounded-xl bg-gradient-primary flex items-center justify-center mb-4">
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <h3 className="font-semibold text-[#333] mb-2">{info.title}</h3>
                  {info.details.map((detail, i) => (
                    <p key={i} className="text-[#666] text-sm">{detail}</p>
                  ))}
                </div>
              );
            })}
          </div>

          {/* Contact Form */}
          <div 
            className="lg:col-span-2"
            style={{
              opacity: isVisible ? 1 : 0,
              transform: isVisible ? 'translateY(0)' : 'translateY(30px)',
              transition: 'all 0.7s var(--ease-expo-out) 400ms',
            }}
          >
            <div className="bg-white rounded-3xl p-8 border border-[#e2e2e2]">
              {isSubmitted ? (
                <div className="text-center py-12">
                  <div className="w-20 h-20 rounded-full bg-[#10b981]/10 flex items-center justify-center mx-auto mb-6">
                    <CheckCircle2 className="w-10 h-10 text-[#10b981]" />
                  </div>
                  <h3 className="text-2xl font-bold font-['Poppins'] text-[#333] mb-2">
                    Message Sent!
                  </h3>
                  <p className="text-[#666]">
                    Thank you for reaching out. We\'ll get back to you within 24 hours.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit} className="space-y-6">
                  <div className="grid sm:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-[#333] mb-2">
                        Full Name *
                      </label>
                      <Input
                        type="text"
                        placeholder="John Doe"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="h-12 rounded-xl border-[#e2e2e2] focus:border-[#2e68ff] focus:ring-2 focus:ring-[#2e68ff]/20"
                        required
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-[#333] mb-2">
                        Email Address *
                      </label>
                      <Input
                        type="email"
                        placeholder="john@example.com"
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="h-12 rounded-xl border-[#e2e2e2] focus:border-[#2e68ff] focus:ring-2 focus:ring-[#2e68ff]/20"
                        required
                      />
                    </div>
                  </div>

                  <div className="grid sm:grid-cols-2 gap-6">
                    <div>
                      <label className="block text-sm font-medium text-[#333] mb-2">
                        Phone Number
                      </label>
                      <Input
                        type="tel"
                        placeholder="+1 (555) 000-0000"
                        value={formData.phone}
                        onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                        className="h-12 rounded-xl border-[#e2e2e2] focus:border-[#2e68ff] focus:ring-2 focus:ring-[#2e68ff]/20"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-[#333] mb-2">
                        Subject *
                      </label>
                      <Input
                        type="text"
                        placeholder="How can we help?"
                        value={formData.subject}
                        onChange={(e) => setFormData({ ...formData, subject: e.target.value })}
                        className="h-12 rounded-xl border-[#e2e2e2] focus:border-[#2e68ff] focus:ring-2 focus:ring-[#2e68ff]/20"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-[#333] mb-2">
                      Message *
                    </label>
                    <Textarea
                      placeholder="Tell us more about your inquiry..."
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      className="min-h-[150px] rounded-xl border-[#e2e2e2] focus:border-[#2e68ff] focus:ring-2 focus:ring-[#2e68ff]/20 resize-none"
                      required
                    />
                  </div>

                  <Button
                    type="submit"
                    className="w-full h-14 bg-[#2e68ff] hover:bg-[#0032b3] text-white rounded-full font-semibold transition-all duration-300 hover:scale-[1.02]"
                  >
                    Send Message
                    <Send className="w-5 h-5 ml-2" />
                  </Button>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;
