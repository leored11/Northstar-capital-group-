import { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Twitter, Linkedin, Facebook, Instagram, ArrowRight } from 'lucide-react';

const Footer = () => {
  const [email, setEmail] = useState('');
  const [isVisible, setIsVisible] = useState(false);
  const footerRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (footerRef.current) {
      observer.observe(footerRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const handleSubscribe = (e: React.FormEvent) => {
    e.preventDefault();
    alert(`Thank you for subscribing with: ${email}`);
    setEmail('');
  };

  const footerLinks = {
    product: {
      title: 'Product',
      links: ['Features', 'Pricing', 'API', 'Mobile App'],
    },
    company: {
      title: 'Company',
      links: ['About Us', 'Careers', 'Blog', 'Press'],
    },
    support: {
      title: 'Support',
      links: ['Help Center', 'Contact', 'Status', 'Community'],
    },
  };

  const socialLinks = [
    { icon: Twitter, href: '#', label: 'Twitter' },
    { icon: Linkedin, href: '#', label: 'LinkedIn' },
    { icon: Facebook, href: '#', label: 'Facebook' },
    { icon: Instagram, href: '#', label: 'Instagram' },
  ];

  return (
    <footer 
      id="footer"
      ref={footerRef}
      className="bg-[#fafafa] pt-20 pb-10"
    >
      <div className="max-w-[1400px] mx-auto px-5">
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-8 pb-12 border-b border-[#e2e2e2]">
          {/* Logo Column */}
          <div 
            className="lg:col-span-4 space-y-6"
            style={{
              opacity: isVisible ? 1 : 0,
              transform: isVisible ? 'translateY(0)' : 'translateY(20px)',
              transition: 'all 0.5s var(--ease-expo-out)',
            }}
          >
            {/* Logo */}
            <a href="#hero" className="flex items-center gap-2">
              <div className="w-10 h-10 rounded-xl bg-gradient-primary flex items-center justify-center">
                <span className="text-white font-bold text-xl font-['Poppins']">N</span>
              </div>
              <span className="text-xl font-bold font-['Poppins'] text-[#333]">NorthStar Capital</span>
            </a>

            <p className="text-[#666] leading-relaxed max-w-sm">
              Empowering investors with zero-commission trading and professional-grade tools. Led by Director James S. Leo, we're committed to your financial success.
            </p>

            {/* Newsletter */}
            <form onSubmit={handleSubscribe} className="flex gap-2">
              <Input
                type="email"
                placeholder="Your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="flex-1 h-11 rounded-full border-[#e2e2e2] focus:border-[#2e68ff] focus:ring-2 focus:ring-[#2e68ff]/20"
                required
              />
              <Button 
                type="submit"
                className="h-11 px-5 bg-[#2e68ff] hover:bg-[#0032b3] text-white rounded-full transition-all duration-300 hover:scale-105"
              >
                <ArrowRight className="w-5 h-5" />
              </Button>
            </form>

            {/* Social Links */}
            <div className="flex gap-3">
              {socialLinks.map((social, index) => {
                const Icon = social.icon;
                return (
                  <a
                    key={index}
                    href={social.href}
                    aria-label={social.label}
                    className="w-10 h-10 rounded-full bg-[#f7f7f7] flex items-center justify-center text-[#333] transition-all duration-300 hover:bg-[#2e68ff] hover:text-white hover:scale-110 hover:rotate-6"
                    style={{
                      opacity: isVisible ? 1 : 0,
                      transform: isVisible ? 'scale(1)' : 'scale(0)',
                      transition: `all 0.3s var(--ease-spring) ${300 + index * 80}ms`,
                    }}
                  >
                    <Icon className="w-5 h-5" />
                  </a>
                );
              })}
            </div>
          </div>

          {/* Links Columns */}
          {Object.entries(footerLinks).map(([key, section], sectionIndex) => (
            <div 
              key={key}
              className="lg:col-span-2"
            >
              <h4 
                className="font-semibold font-['Poppins'] text-[#333] mb-4"
                style={{
                  opacity: isVisible ? 1 : 0,
                  transform: isVisible ? 'translateY(0)' : 'translateY(10px)',
                  transition: `all 0.3s var(--ease-expo-out) ${100 + sectionIndex * 50}ms`,
                }}
              >
                {section.title}
              </h4>
              <ul className="space-y-3">
                {section.links.map((link, linkIndex) => (
                  <li 
                    key={linkIndex}
                    style={{
                      opacity: isVisible ? 1 : 0,
                      transform: isVisible ? 'translateX(0)' : 'translateX(-15px)',
                      transition: `all 0.3s var(--ease-expo-out) ${150 + sectionIndex * 50 + linkIndex * 50}ms`,
                    }}
                  >
                    <a
                      href="#"
                      className="text-[#666] hover:text-[#2e68ff] transition-all duration-200 hover:translate-x-1 inline-block"
                    >
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        {/* Bottom Bar */}
        <div 
          className="pt-8 flex flex-col sm:flex-row items-center justify-between gap-4"
          style={{
            opacity: isVisible ? 1 : 0,
            transition: 'all 0.4s var(--ease-expo-out) 600ms',
          }}
        >
          <p className="text-sm text-[#999]">
            © 2024 NorthStar Capital Group. All rights reserved.
          </p>
          
          <div className="flex gap-6">
            {['Privacy Policy', 'Terms of Service', 'Cookie Policy'].map((text, index) => (
              <a
                key={index}
                href="#"
                className="text-sm text-[#999] hover:text-[#2e68ff] transition-colors duration-200"
              >
                {text}
              </a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
