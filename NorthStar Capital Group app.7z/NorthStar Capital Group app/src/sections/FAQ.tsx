import { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { ChevronDown, MessageCircle } from 'lucide-react';

const FAQ = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [openIndex, setOpenIndex] = useState<number | null>(2);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const faqs = [
    {
      question: "Is InvestHub really commission-free?",
      answer: "Yes! InvestHub offers zero-commission trading on stocks, ETFs, and options. We believe everyone should have access to the markets without paying excessive fees. There are no hidden charges or surprise costs."
    },
    {
      question: "How do I get started with trading?",
      answer: "Getting started is easy. Simply sign up with your email, complete our secure verification process, link your bank account, and you can start trading within minutes. We also offer a demo account to practice before trading with real money."
    },
    {
      question: "What types of accounts does NorthStar offer?",
      answer: "We offer a variety of account types to suit your needs: Individual brokerage accounts, Joint accounts, Traditional and Roth IRAs, and Business accounts. Each account type has its own benefits and tax implications."
    },
    {
      question: "Is my money safe with NorthStar?",
      answer: "Absolutely. NorthStar Capital Group is a member of SIPC, which protects securities customers of its members up to $500,000. We also use bank-level encryption, two-factor authentication, and keep your assets in segregated accounts for maximum security."
    },
    {
      question: "Can I trade on mobile?",
      answer: "Yes! Our mobile app is available for both iOS and Android devices. You get the same powerful features as our desktop platform, including real-time quotes, advanced charting, and instant trade execution, all optimized for mobile."
    },
  ];

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section 
      id="faq"
      ref={sectionRef}
      className="py-24 bg-white"
    >
      <div className="max-w-[1400px] mx-auto px-5">
        <div className="grid lg:grid-cols-12 gap-12 lg:gap-20">
          {/* Left Column - Sticky Title */}
          <div className="lg:col-span-4">
            <div className="lg:sticky lg:top-32 space-y-6">
              <div
                style={{
                  opacity: isVisible ? 1 : 0,
                  transform: isVisible ? 'translateX(0)' : 'translateX(-40px)',
                  transition: 'all 0.6s var(--ease-expo-out)',
                }}
              >
                <span className="inline-block px-4 py-2 bg-[#2e68ff]/10 text-[#2e68ff] rounded-full text-sm font-semibold mb-4">
                  FAQ
                </span>
                <h2 className="text-3xl sm:text-4xl font-bold font-['Poppins'] text-[#333] mb-4">
                  Frequently Asked <span className="text-gradient">Questions</span>
                </h2>
                <p 
                  className="text-[#666] leading-relaxed"
                  style={{
                    opacity: isVisible ? 1 : 0,
                    transform: isVisible ? 'translateY(0)' : 'translateY(20px)',
                    transition: 'all 0.5s var(--ease-expo-out) 200ms',
                  }}
                >
                  Everything you need to know about NorthStar Capital Group. Can't find what you're looking for? Reach out to our support team.
                </p>
              </div>

              <Button 
                variant="outline"
                className="flex items-center gap-2 px-6 py-3 rounded-full border-2 border-[#2e68ff] text-[#2e68ff] hover:bg-[#2e68ff] hover:text-white transition-all duration-300 group"
                style={{
                  opacity: isVisible ? 1 : 0,
                  transform: isVisible ? 'scale(1)' : 'scale(0.9)',
                  transition: 'all 0.4s var(--ease-spring) 400ms',
                }}
              >
                <MessageCircle className="w-5 h-5" />
                Contact Us
              </Button>
            </div>
          </div>

          {/* Right Column - Accordion */}
          <div className="lg:col-span-8 space-y-4">
            {faqs.map((faq, index) => {
              const isOpen = openIndex === index;
              
              return (
                <div
                  key={index}
                  className={`rounded-2xl border-2 transition-all duration-300 overflow-hidden ${
                    isOpen 
                      ? 'bg-[#f7f7f7] border-[#2e68ff]' 
                      : 'bg-white border-[#e2e2e2] hover:border-[#2e68ff]/50 hover:bg-[#fafafa]'
                  }`}
                  style={{
                    opacity: isVisible ? 1 : 0,
                    transform: isVisible ? 'translateX(0)' : 'translateX(40px)',
                    transition: `all 0.5s var(--ease-expo-out) ${100 + index * 100}ms`,
                  }}
                >
                  <button
                    onClick={() => toggleFAQ(index)}
                    className="w-full flex items-center justify-between p-6 text-left"
                  >
                    <span className={`font-semibold font-['Poppins'] pr-4 ${
                      isOpen ? 'text-[#2e68ff]' : 'text-[#333]'
                    }`}>
                      {faq.question}
                    </span>
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 transition-all duration-300 ${
                      isOpen ? 'bg-[#2e68ff]' : 'bg-[#f7f7f7]'
                    }`}>
                      <ChevronDown 
                        className={`w-5 h-5 transition-all duration-300 ${
                          isOpen ? 'text-white rotate-180' : 'text-[#666]'
                        }`}
                      />
                    </div>
                  </button>
                  
                  <div 
                    className={`overflow-hidden transition-all duration-400 ${
                      isOpen ? 'max-h-96' : 'max-h-0'
                    }`}
                    style={{ transitionTimingFunction: 'var(--ease-expo-out)' }}
                  >
                    <div className="px-6 pb-6">
                      <p className="text-[#666] leading-relaxed">
                        {faq.answer}
                      </p>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
};

export default FAQ;
