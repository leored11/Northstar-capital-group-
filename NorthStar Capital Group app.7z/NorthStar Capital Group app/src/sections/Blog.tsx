import { useEffect, useRef, useState } from 'react';
import { ArrowRight, Calendar, Clock, User } from 'lucide-react';

const Blog = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const articles = [
    {
      category: 'Market Analysis',
      title: 'Tech Stocks Rally: What Investors Need to Know in 2024',
      excerpt: 'The technology sector continues to show resilience despite market volatility. Our analysis of the top performers and what to watch.',
      author: 'James S. Leo',
      date: 'Feb 18, 2024',
      readTime: '5 min read',
      image: '/blog-tech.jpg',
      featured: true,
    },
    {
      category: 'Investment Strategy',
      title: 'Building a Diversified Portfolio: A Beginner\'s Guide',
      excerpt: 'Learn the fundamentals of portfolio diversification and how to balance risk and reward.',
      author: 'Sarah Chen',
      date: 'Feb 15, 2024',
      readTime: '8 min read',
      image: '/blog-portfolio.jpg',
      featured: false,
    },
    {
      category: 'Crypto',
      title: 'Bitcoin ETF Approval: Impact on Digital Assets',
      excerpt: 'The recent approval of Bitcoin ETFs marks a milestone for cryptocurrency adoption in traditional finance.',
      author: 'Michael Roberts',
      date: 'Feb 12, 2024',
      readTime: '6 min read',
      image: '/blog-crypto.jpg',
      featured: false,
    },
    {
      category: 'Retirement',
      title: 'Maximizing Your 401(k): Strategies for Every Age',
      excerpt: 'Whether you\'re just starting out or nearing retirement, here are key strategies to optimize your retirement savings.',
      author: 'Isabella Martinez',
      date: 'Feb 10, 2024',
      readTime: '7 min read',
      image: '/blog-retirement.jpg',
      featured: false,
    },
  ];

  const featuredArticle = articles.find(a => a.featured);
  const regularArticles = articles.filter(a => !a.featured);

  return (
    <section 
      id="blog"
      ref={sectionRef}
      className="py-24 bg-[#fafafa]"
    >
      <div className="max-w-[1400px] mx-auto px-5">
        {/* Section Header */}
        <div 
          className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6 mb-12"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(40px)',
            transition: 'all 0.7s var(--ease-expo-out)',
          }}
        >
          <div>
            <span className="inline-block px-4 py-2 bg-[#ffba07]/20 text-[#ffba07] rounded-full text-sm font-semibold mb-4">
              Insights
            </span>
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-['Poppins'] text-[#333] mb-4">
              Market <span className="text-gradient">Insights</span>
            </h2>
            <p className="text-lg text-[#666] max-w-xl">
              Expert analysis and investment strategies from our team
            </p>
          </div>
          <a 
            href="#"
            className="inline-flex items-center gap-2 text-[#2e68ff] font-semibold hover:gap-3 transition-all duration-300"
          >
            View All Articles
            <ArrowRight className="w-5 h-5" />
          </a>
        </div>

        {/* Featured Article */}
        {featuredArticle && (
          <div 
            className="mb-8"
            style={{
              opacity: isVisible ? 1 : 0,
              transform: isVisible ? 'translateY(0)' : 'translateY(40px)',
              transition: 'all 0.7s var(--ease-expo-out) 200ms',
            }}
          >
            <div className="group bg-white rounded-3xl overflow-hidden border border-[#e2e2e2] hover:shadow-2xl transition-all duration-300">
              <div className="grid lg:grid-cols-2">
                <div className="h-64 lg:h-auto bg-gradient-to-br from-[#2e68ff]/20 to-[#ffba07]/20 flex items-center justify-center">
                  <div className="text-center">
                    <div className="w-24 h-24 mx-auto rounded-2xl bg-gradient-primary flex items-center justify-center mb-4">
                      <span className="text-4xl font-bold text-white">{featuredArticle.category.charAt(0)}</span>
                    </div>
                    <p className="text-[#666] font-medium">{featuredArticle.category}</p>
                  </div>
                </div>
                <div className="p-8 lg:p-12">
                  <span className="inline-block px-3 py-1 bg-[#2e68ff]/10 text-[#2e68ff] rounded-full text-xs font-semibold mb-4">
                    Featured
                  </span>
                  <h3 className="text-2xl lg:text-3xl font-bold font-['Poppins'] text-[#333] mb-4 group-hover:text-[#2e68ff] transition-colors">
                    {featuredArticle.title}
                  </h3>
                  <p className="text-[#666] leading-relaxed mb-6">
                    {featuredArticle.excerpt}
                  </p>
                  <div className="flex items-center gap-4 text-sm text-[#999]">
                    <div className="flex items-center gap-1">
                      <User className="w-4 h-4" />
                      {featuredArticle.author}
                    </div>
                    <div className="flex items-center gap-1">
                      <Calendar className="w-4 h-4" />
                      {featuredArticle.date}
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      {featuredArticle.readTime}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Regular Articles Grid */}
        <div className="grid md:grid-cols-3 gap-6">
          {regularArticles.map((article, index) => (
            <article
              key={index}
              className="group bg-white rounded-2xl p-6 border border-[#e2e2e2] hover:shadow-xl hover:border-[#2e68ff] transition-all duration-300"
              style={{
                opacity: isVisible ? 1 : 0,
                transform: isVisible ? 'translateY(0)' : 'translateY(40px)',
                transition: `all 0.7s var(--ease-expo-out) ${400 + index * 100}ms`,
              }}
            >
              <span className="inline-block px-3 py-1 bg-[#f7f7f7] text-[#666] rounded-full text-xs font-semibold mb-4">
                {article.category}
              </span>
              <h3 className="text-lg font-bold font-['Poppins'] text-[#333] mb-3 group-hover:text-[#2e68ff] transition-colors line-clamp-2">
                {article.title}
              </h3>
              <p className="text-[#666] text-sm leading-relaxed mb-4 line-clamp-3">
                {article.excerpt}
              </p>
              <div className="flex items-center gap-3 text-xs text-[#999]">
                <div className="flex items-center gap-1">
                  <Calendar className="w-3 h-3" />
                  {article.date}
                </div>
                <div className="flex items-center gap-1">
                  <Clock className="w-3 h-3" />
                  {article.readTime}
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Blog;
