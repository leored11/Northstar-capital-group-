import { useEffect, useRef, useState } from 'react';
import { Briefcase, MapPin, DollarSign, ArrowRight, CheckCircle2, Heart, Zap, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from '@/components/ui/dialog';

const Careers = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [selectedJob, setSelectedJob] = useState<typeof jobs[0] | null>(null);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const benefits = [
    { icon: DollarSign, title: 'Competitive Salary', description: 'Above-market compensation with annual bonuses' },
    { icon: Heart, title: 'Health & Wellness', description: 'Comprehensive health, dental, and vision coverage' },
    { icon: Zap, title: 'Learning Budget', description: '$5,000 annual budget for courses and conferences' },
    { icon: Users, title: 'Team Events', description: 'Regular team outings and company retreats' },
  ];

  const jobs = [
    {
      title: 'Senior Software Engineer',
      department: 'Engineering',
      location: 'New York, NY (Hybrid)',
      salary: '$150K - $200K',
      type: 'Full-time',
      description: 'Join our engineering team to build the next generation of trading platforms. You\'ll work with cutting-edge technologies and help scale our infrastructure to serve millions of users.',
      requirements: [
        '5+ years of experience in software engineering',
        'Strong proficiency in React, TypeScript, and Node.js',
        'Experience with financial systems or trading platforms',
        'Bachelor\'s degree in Computer Science or equivalent',
      ],
    },
    {
      title: 'Financial Analyst',
      department: 'Finance',
      location: 'New York, NY (On-site)',
      salary: '$80K - $120K',
      type: 'Full-time',
      description: 'Analyze market trends, prepare financial reports, and support investment decisions. Work closely with our portfolio management team to deliver insights.',
      requirements: [
        '3+ years of experience in financial analysis',
        'CFA or CPA certification preferred',
        'Strong Excel and financial modeling skills',
        'Bachelor\'s degree in Finance, Economics, or related field',
      ],
    },
    {
      title: 'Customer Success Manager',
      department: 'Customer Success',
      location: 'Remote',
      salary: '$70K - $95K',
      type: 'Full-time',
      description: 'Help our clients achieve their investment goals. Provide exceptional support, onboard new users, and build lasting relationships with our growing client base.',
      requirements: [
        '3+ years in customer success or account management',
        'Experience in fintech or financial services',
        'Excellent communication and problem-solving skills',
        'Series 7 license preferred',
      ],
    },
    {
      title: 'Product Designer',
      department: 'Design',
      location: 'New York, NY (Hybrid)',
      salary: '$100K - $140K',
      type: 'Full-time',
      description: 'Design intuitive and beautiful experiences for our trading platform. Collaborate with engineering and product teams to deliver user-centered solutions.',
      requirements: [
        '4+ years of product design experience',
        'Strong portfolio demonstrating UI/UX skills',
        'Proficiency in Figma and design systems',
        'Experience in fintech or complex data visualization',
      ],
    },
  ];

  return (
    <section 
      id="careers"
      ref={sectionRef}
      className="py-24 bg-white"
    >
      <div className="max-w-[1400px] mx-auto px-5">
        {/* Section Header */}
        <div 
          className="text-center mb-16"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(40px)',
            transition: 'all 0.7s var(--ease-expo-out)',
          }}
        >
          <span className="inline-block px-4 py-2 bg-[#2e68ff]/10 text-[#2e68ff] rounded-full text-sm font-semibold mb-4">
            Join Our Team
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-['Poppins'] text-[#333] mb-4">
            Build Your <span className="text-gradient">Career</span> With Us
          </h2>
          <p className="text-lg text-[#666] max-w-2xl mx-auto">
            Join a team that\'s democratizing access to professional-grade investment tools
          </p>
        </div>

        {/* Benefits */}
        <div 
          className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-16"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(40px)',
            transition: 'all 0.7s var(--ease-expo-out) 200ms',
          }}
        >
          {benefits.map((benefit, index) => {
            const Icon = benefit.icon;
            return (
              <div 
                key={index}
                className="text-center p-6 bg-[#fafafa] rounded-2xl hover:shadow-lg transition-all duration-300"
              >
                <div className="w-14 h-14 rounded-xl bg-gradient-primary flex items-center justify-center mx-auto mb-4">
                  <Icon className="w-7 h-7 text-white" />
                </div>
                <h3 className="font-semibold text-[#333] mb-2">{benefit.title}</h3>
                <p className="text-sm text-[#666]">{benefit.description}</p>
              </div>
            );
          })}
        </div>

        {/* Job Listings */}
        <div className="space-y-4">
          <h3 
            className="text-2xl font-bold font-['Poppins'] text-[#333] mb-6"
            style={{
              opacity: isVisible ? 1 : 0,
              transform: isVisible ? 'translateY(0)' : 'translateY(20px)',
              transition: 'all 0.6s var(--ease-expo-out) 400ms',
            }}
          >
            Open Positions
          </h3>
          
          {jobs.map((job, index) => (
            <div
              key={index}
              className="group bg-[#fafafa] rounded-2xl p-6 border border-[#e2e2e2] hover:border-[#2e68ff] hover:shadow-lg transition-all duration-300 cursor-pointer"
              onClick={() => setSelectedJob(job)}
              style={{
                opacity: isVisible ? 1 : 0,
                transform: isVisible ? 'translateX(0)' : 'translateX(-30px)',
                transition: `all 0.5s var(--ease-expo-out) ${500 + index * 100}ms`,
              }}
            >
              <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
                <div>
                  <h4 className="text-lg font-bold font-['Poppins'] text-[#333] group-hover:text-[#2e68ff] transition-colors mb-2">
                    {job.title}
                  </h4>
                  <div className="flex flex-wrap items-center gap-4 text-sm text-[#666]">
                    <span className="flex items-center gap-1">
                      <Briefcase className="w-4 h-4" />
                      {job.department}
                    </span>
                    <span className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      {job.location}
                    </span>
                    <span className="flex items-center gap-1">
                      <DollarSign className="w-4 h-4" />
                      {job.salary}
                    </span>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <span className="px-3 py-1 bg-[#2e68ff]/10 text-[#2e68ff] rounded-full text-sm font-medium">
                    {job.type}
                  </span>
                  <ArrowRight className="w-5 h-5 text-[#999] group-hover:text-[#2e68ff] group-hover:translate-x-1 transition-all" />
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Don't see a fit? */}
        <div 
          className="text-center mt-12 p-8 bg-gradient-to-r from-[#2e68ff]/5 to-[#ffba07]/5 rounded-2xl"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(20px)',
            transition: 'all 0.6s var(--ease-expo-out) 800ms',
          }}
        >
          <h4 className="text-xl font-bold font-['Poppins'] text-[#333] mb-2">
            Don\'t see a perfect fit?
          </h4>
          <p className="text-[#666] mb-4">
            We\'re always looking for talented individuals. Send us your resume and we\'ll keep you in mind for future opportunities.
          </p>
          <Button className="bg-[#2e68ff] hover:bg-[#0032b3] text-white rounded-full px-6">
            Send General Application
          </Button>
        </div>
      </div>

      {/* Job Detail Dialog */}
      <Dialog open={!!selectedJob} onOpenChange={() => setSelectedJob(null)}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-2xl font-bold font-['Poppins']">
              {selectedJob?.title}
            </DialogTitle>
            <DialogDescription className="text-[#666]">
              <div className="flex flex-wrap items-center gap-4 mt-2">
                <span className="flex items-center gap-1">
                  <Briefcase className="w-4 h-4" />
                  {selectedJob?.department}
                </span>
                <span className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  {selectedJob?.location}
                </span>
                <span className="flex items-center gap-1">
                  <DollarSign className="w-4 h-4" />
                  {selectedJob?.salary}
                </span>
              </div>
            </DialogDescription>
          </DialogHeader>
          
          <div className="space-y-6 mt-4">
            <div>
              <h4 className="font-semibold text-[#333] mb-2">About the Role</h4>
              <p className="text-[#666] leading-relaxed">{selectedJob?.description}</p>
            </div>
            
            <div>
              <h4 className="font-semibold text-[#333] mb-3">Requirements</h4>
              <ul className="space-y-2">
                {selectedJob?.requirements.map((req, index) => (
                  <li key={index} className="flex items-start gap-2">
                    <CheckCircle2 className="w-5 h-5 text-[#10b981] flex-shrink-0 mt-0.5" />
                    <span className="text-[#666]">{req}</span>
                  </li>
                ))}
              </ul>
            </div>
            
            <div className="pt-4 border-t border-[#e2e2e2]">
              <Button className="w-full bg-[#2e68ff] hover:bg-[#0032b3] text-white rounded-full py-6">
                Apply for this Position
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </section>
  );
};

export default Careers;
