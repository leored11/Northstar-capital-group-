import { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Check, ArrowRight } from 'lucide-react';

const About = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const features = [
    'Real-time market data and alerts',
    'Customizable watchlists and portfolios',
    'Expert research and insights',
  ];

  return (
    <section 
      id="about"
      ref={sectionRef}
      className="py-24 bg-white overflow-hidden"
    >
      <div className="max-w-[1400px] mx-auto px-5">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
          {/* Left - Image */}
          <div 
            className="relative perspective-1000"
            style={{
              opacity: isVisible ? 1 : 0,
              transform: isVisible ? 'translateX(0) rotateY(0)' : 'translateX(-100px) rotateY(-15deg)',
              transition: 'all 1s var(--ease-expo-out)',
            }}
          >
            <div className="relative">
              <img
                src="/about-image.jpg"
                alt="About InvestHub"
                className="w-full max-w-md mx-auto rounded-3xl shadow-2xl transition-all duration-400 hover:scale-[1.03]"
              />
              
              {/* Floating decorative elements */}
              <div 
                className="absolute -top-6 -right-6 w-24 h-24 rounded-2xl bg-[#ffba07]/20 animate-float"
              />
              <div 
                className="absolute -bottom-6 -left-6 w-16 h-16 rounded-xl bg-[#2e68ff]/20 animate-float-delayed"
              />

              {/* Stats Card */}
              <div 
                className="absolute bottom-8 -right-4 lg:right-8 bg-white rounded-2xl shadow-xl p-5 animate-float"
                style={{
                  opacity: isVisible ? 1 : 0,
                  transform: isVisible ? 'translateY(0) scale(1)' : 'translateY(50px) scale(0.8)',
                  transition: 'all 0.8s var(--ease-spring) 600ms',
                }}
              >
                <div className="flex items-center gap-4">
                  <div className="w-14 h-14 rounded-xl bg-gradient-primary flex items-center justify-center">
                    <span className="text-2xl font-bold text-white">$</span>
                  </div>
                  <div>
                    <p className="text-3xl font-bold text-[#333] font-['Poppins']">$2.5B+</p>
                    <p className="text-sm text-[#999]">Assets Managed</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right - Content */}
          <div className="space-y-6">
            {/* Badge */}
            <div
              style={{
                opacity: isVisible ? 1 : 0,
                transform: isVisible ? 'scale(1)' : 'scale(0.8)',
                transition: 'all 0.4s var(--ease-spring) 300ms',
              }}
            >
              <span className="inline-block px-4 py-2 bg-[#2e68ff]/10 text-[#2e68ff] rounded-full text-sm font-semibold">
                About NorthStar
              </span>
            </div>

            {/* Title */}
            <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-['Poppins'] text-[#333] leading-tight">
              {'Built for Modern Investors'.split(' ').map((word, index) => (
                <span
                  key={index}
                  className="inline-block mr-2"
                  style={{
                    opacity: isVisible ? 1 : 0,
                    clipPath: isVisible ? 'inset(0)' : 'inset(0 100% 0 0)',
                    transition: `all 0.6s var(--ease-expo-out) ${400 + index * 100}ms`,
                  }}
                >
                  {word}
                </span>
              ))}
            </h2>

            {/* Description */}
            <p 
              className="text-lg text-[#666] leading-relaxed"
              style={{
                opacity: isVisible ? 1 : 0,
                transform: isVisible ? 'translateY(0)' : 'translateY(20px)',
                transition: 'all 0.5s var(--ease-expo-out) 700ms',
              }}
            >
              We believe investing should be accessible to everyone. That's why we've created a platform that combines powerful tools with an intuitive interface, making it easy for both beginners and experienced traders to achieve their financial goals.
            </p>

            {/* Features List */}
            <div className="space-y-4 pt-4">
              {features.map((feature, index) => (
                <div
                  key={index}
                  className="flex items-center gap-3 group"
                  style={{
                    opacity: isVisible ? 1 : 0,
                    transform: isVisible ? 'translateX(0)' : 'translateX(-30px)',
                    transition: `all 0.4s var(--ease-expo-out) ${800 + index * 100}ms`,
                  }}
                >
                  <div className="w-6 h-6 rounded-full bg-[#2e68ff] flex items-center justify-center flex-shrink-0 transition-all duration-300 group-hover:bg-[#ffba07] group-hover:scale-110">
                    <Check className="w-4 h-4 text-white" strokeWidth={3} />
                  </div>
                  <span className="text-[#333] font-medium">{feature}</span>
                </div>
              ))}
            </div>

            {/* CTA Button */}
            <div
              style={{
                opacity: isVisible ? 1 : 0,
                transform: isVisible ? 'scale(1)' : 'scale(0.9)',
                transition: 'all 0.4s var(--ease-spring) 1100ms',
              }}
            >
              <Button 
                variant="outline"
                className="mt-6 px-8 py-3 rounded-full border-2 border-[#2e68ff] text-[#2e68ff] hover:bg-[#2e68ff] hover:text-white transition-all duration-300 group"
              >
                Learn More
                <ArrowRight className="w-5 h-5 ml-2 transition-transform duration-300 group-hover:translate-x-1" />
              </Button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;
