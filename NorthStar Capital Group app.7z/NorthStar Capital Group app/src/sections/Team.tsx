import { useEffect, useRef, useState } from 'react';
import { Linkedin, Mail, Twitter } from 'lucide-react';

const Team = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const teamMembers = [
    {
      name: 'Sarah Chen',
      role: 'Chief Technology Officer',
      bio: 'Former Google engineer with 15+ years building fintech platforms.',
      image: '/team-cto.jpg',
      social: { linkedin: '#', twitter: '#', email: '#' },
    },
    {
      name: 'Michael Roberts',
      role: 'Chief Financial Officer',
      bio: 'Ex-JPMorgan with expertise in risk management and compliance.',
      image: '/team-cfo.jpg',
      social: { linkedin: '#', twitter: '#', email: '#' },
    },
    {
      name: 'Isabella Martinez',
      role: 'Head of Client Relations',
      bio: 'Dedicated to providing exceptional service to our 20,000+ clients.',
      image: '/team-client-relations.jpg',
      social: { linkedin: '#', twitter: '#', email: '#' },
    },
  ];

  return (
    <section 
      id="team"
      ref={sectionRef}
      className="py-24 bg-[#fafafa]"
    >
      <div className="max-w-[1400px] mx-auto px-5">
        {/* Section Header */}
        <div 
          className="text-center mb-16"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(40px)',
            transition: 'all 0.7s var(--ease-expo-out)',
          }}
        >
          <span className="inline-block px-4 py-2 bg-[#ffba07]/20 text-[#ffba07] rounded-full text-sm font-semibold mb-4">
            Our Team
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-['Poppins'] text-[#333] mb-4">
            Meet the <span className="text-gradient">Experts</span>
          </h2>
          <p className="text-lg text-[#666] max-w-2xl mx-auto">
            A world-class team dedicated to your financial success
          </p>
        </div>

        {/* Team Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {teamMembers.map((member, index) => (
            <div
              key={index}
              className="group bg-white rounded-3xl p-6 border border-[#e2e2e2] transition-all duration-300 hover:-translate-y-3 hover:shadow-2xl hover:border-[#2e68ff] text-center"
              style={{
                opacity: isVisible ? 1 : 0,
                transform: isVisible ? 'translateY(0)' : 'translateY(60px)',
                transition: `all 0.7s var(--ease-expo-out) ${200 + index * 150}ms`,
              }}
            >
              {/* Photo */}
              <div className="relative mx-auto w-32 h-32 mb-6">
                <div className="absolute inset-0 rounded-full bg-gradient-primary p-1">
                  <div className="w-full h-full rounded-full overflow-hidden">
                    <img 
                      src={member.image} 
                      alt={member.name}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-110"
                    />
                  </div>
                </div>
              </div>

              {/* Info */}
              <h3 className="text-xl font-bold font-['Poppins'] text-[#333] mb-1 group-hover:text-[#2e68ff] transition-colors">
                {member.name}
              </h3>
              <p className="text-[#2e68ff] font-medium text-sm mb-3">
                {member.role}
              </p>
              <p className="text-[#666] text-sm leading-relaxed mb-4">
                {member.bio}
              </p>

              {/* Social Links */}
              <div className="flex justify-center gap-3">
                <a 
                  href={member.social.linkedin}
                  className="w-9 h-9 rounded-full bg-[#f7f7f7] flex items-center justify-center text-[#666] hover:bg-[#2e68ff] hover:text-white transition-all duration-300 hover:scale-110"
                  aria-label="LinkedIn"
                >
                  <Linkedin className="w-4 h-4" />
                </a>
                <a 
                  href={member.social.twitter}
                  className="w-9 h-9 rounded-full bg-[#f7f7f7] flex items-center justify-center text-[#666] hover:bg-[#2e68ff] hover:text-white transition-all duration-300 hover:scale-110"
                  aria-label="Twitter"
                >
                  <Twitter className="w-4 h-4" />
                </a>
                <a 
                  href={member.social.email}
                  className="w-9 h-9 rounded-full bg-[#f7f7f7] flex items-center justify-center text-[#666] hover:bg-[#2e68ff] hover:text-white transition-all duration-300 hover:scale-110"
                  aria-label="Email"
                >
                  <Mail className="w-4 h-4" />
                </a>
              </div>
            </div>
          ))}
        </div>

        {/* Join Team CTA */}
        <div 
          className="text-center mt-12"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(20px)',
            transition: 'all 0.6s var(--ease-expo-out) 800ms',
          }}
        >
          <p className="text-[#666] mb-4">Want to join our team?</p>
          <a 
            href="#careers"
            className="inline-flex items-center gap-2 px-6 py-3 bg-[#2e68ff] hover:bg-[#0032b3] text-white rounded-full font-medium transition-all duration-300 hover:scale-105"
          >
            View Open Positions
          </a>
        </div>
      </div>
    </section>
  );
};

export default Team;
