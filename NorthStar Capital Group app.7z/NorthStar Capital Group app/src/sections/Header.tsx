import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Menu, X, ChevronDown } from 'lucide-react';

const Header = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navItems = [
    { label: 'Home', href: '#hero' },
    { label: 'About', href: '#about' },
    { label: 'Team', href: '#team' },
    { label: 'How to Invest', href: '#how-to-invest' },
    { label: 'Calculator', href: '#calculator' },
    { label: 'Pricing', href: '#pricing' },
    { 
      label: 'More', 
      href: '#',
      dropdown: [
        { label: 'Features', href: '#features' },
        { label: 'Dashboard', href: '#dashboard' },
        { label: 'Blog', href: '#blog' },
        { label: 'Careers', href: '#careers' },
        { label: 'Testimonials', href: '#testimonials' },
        { label: 'FAQ', href: '#faq' },
        { label: 'Contact', href: '#contact' },
      ]
    },
  ];

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
    setIsMobileMenuOpen(false);
    setIsDropdownOpen(false);
  };

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        isScrolled
          ? 'glass shadow-lg py-3'
          : 'bg-transparent py-5'
      }`}
      style={{ transitionTimingFunction: 'var(--ease-expo-out)' }}
    >
      <div className="max-w-[1400px] mx-auto px-5 flex items-center justify-between">
        {/* Logo */}
        <a 
          href="#hero" 
          onClick={(e) => { e.preventDefault(); scrollToSection('#hero'); }}
          className="flex items-center gap-2 transition-transform duration-300 hover:scale-105"
        >
          <div className="w-10 h-10 rounded-xl bg-gradient-primary flex items-center justify-center">
            <span className="text-white font-bold text-xl font-['Poppins']">N</span>
          </div>
          <span className="text-xl font-bold font-['Poppins'] text-[#333]">NorthStar Capital</span>
        </a>

        {/* Desktop Navigation */}
        <nav className="hidden lg:flex items-center gap-8">
          {navItems.map((item, index) => (
            <div key={index} className="relative">
              {item.dropdown ? (
                <div
                  className="relative"
                  onMouseEnter={() => setIsDropdownOpen(true)}
                  onMouseLeave={() => setIsDropdownOpen(false)}
                >
                  <button
                    className="flex items-center gap-1 text-[#333] font-medium hover:text-[#2e68ff] transition-colors duration-300 relative group"
                  >
                    {item.label}
                    <ChevronDown className={`w-4 h-4 transition-transform duration-300 ${isDropdownOpen ? 'rotate-180' : ''}`} />
                    <span className="absolute -bottom-1 left-1/2 w-0 h-0.5 bg-[#2e68ff] transition-all duration-300 group-hover:w-full group-hover:left-0" />
                  </button>
                  
                  {isDropdownOpen && (
                    <div 
                      className="absolute top-full left-0 mt-2 w-48 bg-white rounded-xl shadow-xl border border-[#e2e2e2] py-2 overflow-hidden"
                      style={{ 
                        animation: 'dropdown-appear 0.3s var(--ease-expo-out)',
                        transformOrigin: 'top center'
                      }}
                    >
                      {item.dropdown.map((subItem, subIndex) => (
                        <a
                          key={subIndex}
                          href={subItem.href}
                          onClick={(e) => { e.preventDefault(); scrollToSection(subItem.href); }}
                          className="block px-4 py-2 text-[#333] hover:bg-[#f7f7f7] hover:text-[#2e68ff] transition-colors duration-200"
                        >
                          {subItem.label}
                        </a>
                      ))}
                    </div>
                  )}
                </div>
              ) : (
                <a
                  href={item.href}
                  onClick={(e) => { e.preventDefault(); scrollToSection(item.href); }}
                  className="text-[#333] font-medium hover:text-[#2e68ff] transition-colors duration-300 relative group"
                >
                  {item.label}
                  <span className="absolute -bottom-1 left-1/2 w-0 h-0.5 bg-[#2e68ff] transition-all duration-300 group-hover:w-full group-hover:left-0" />
                </a>
              )}
            </div>
          ))}
        </nav>

        {/* CTA Button */}
        <div className="hidden lg:block">
          <Button 
            className="bg-[#2e68ff] hover:bg-[#0032b3] text-white px-6 py-2.5 rounded-full font-medium transition-all duration-300 hover:scale-105 hover:shadow-lg hover:shadow-[#2e68ff]/30"
            onClick={() => scrollToSection('#cta')}
          >
            Get Started
          </Button>
        </div>

        {/* Mobile Menu Button */}
        <button
          className="lg:hidden p-2 text-[#333]"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
        >
          {isMobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isMobileMenuOpen && (
        <div 
          className="lg:hidden absolute top-full left-0 right-0 bg-white shadow-xl border-t border-[#e2e2e2]"
          style={{ animation: 'slide-down 0.3s var(--ease-expo-out)' }}
        >
          <nav className="flex flex-col p-5 gap-4">
            {navItems.map((item, index) => (
              <div key={index}>
                {item.dropdown ? (
                  <div className="space-y-2">
                    <span className="font-medium text-[#333]">{item.label}</span>
                    <div className="pl-4 space-y-2">
                      {item.dropdown.map((subItem, subIndex) => (
                        <a
                          key={subIndex}
                          href={subItem.href}
                          onClick={(e) => { e.preventDefault(); scrollToSection(subItem.href); }}
                          className="block text-[#666] hover:text-[#2e68ff] transition-colors"
                        >
                          {subItem.label}
                        </a>
                      ))}
                    </div>
                  </div>
                ) : (
                  <a
                    href={item.href}
                    onClick={(e) => { e.preventDefault(); scrollToSection(item.href); }}
                    className="block text-[#333] font-medium hover:text-[#2e68ff] transition-colors"
                  >
                    {item.label}
                  </a>
                )}
              </div>
            ))}
            <Button 
              className="bg-[#2e68ff] hover:bg-[#0032b3] text-white w-full rounded-full mt-4"
              onClick={() => scrollToSection('#cta')}
            >
              Get Started
            </Button>
          </nav>
        </div>
      )}

      <style>{`
        @keyframes dropdown-appear {
          from {
            opacity: 0;
            transform: scale(0.95) rotateX(-10deg);
          }
          to {
            opacity: 1;
            transform: scale(1) rotateX(0deg);
          }
        }
        @keyframes slide-down {
          from {
            opacity: 0;
            transform: translateY(-10px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
    </header>
  );
};

export default Header;
