import { useEffect, useRef, useState } from 'react';
import { Star, Quote } from 'lucide-react';

const Testimonials = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const testimonials = [
    {
      quote: "InvestHub has completely transformed how I invest. The zero-commission model and powerful tools have helped me grow my portfolio by 40% in just one year.",
      rating: 5,
      name: "Sarah Mitchell",
      role: "Day Trader",
      avatar: "/avatar-1.jpg",
      offset: 0,
    },
    {
      quote: "The real-time data and advanced charting features are game-changers. I've used many platforms, but InvestHub is by far the most intuitive and powerful.",
      rating: 5,
      name: "James Chen",
      role: "Portfolio Manager",
      avatar: "/avatar-2.jpg",
      offset: 30,
    },
    {
      quote: "As a beginner investor, I was intimidated by trading. InvestHub made it simple and accessible. The educational resources are incredible.",
      rating: 5,
      name: "Emily Rodriguez",
      role: "First-time Investor",
      avatar: "/avatar-3.jpg",
      offset: 15,
    },
  ];

  return (
    <section 
      id="testimonials"
      ref={sectionRef}
      className="py-24 bg-[#fafafa]"
    >
      <div className="max-w-[1400px] mx-auto px-5">
        {/* Section Header */}
        <div 
          className="text-center mb-16"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(40px)',
            transition: 'all 0.7s var(--ease-expo-out)',
          }}
        >
          <span className="inline-block px-4 py-2 bg-[#ffba07]/20 text-[#ffba07] rounded-full text-sm font-semibold mb-4">
            Testimonials
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-['Poppins'] text-[#333] mb-4">
            What Our <span className="text-gradient">Traders</span> Say
          </h2>
          <p className="text-lg text-[#666] max-w-2xl mx-auto">
            Join thousands of satisfied investors who trust InvestHub
          </p>
        </div>

        {/* Testimonials Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div
              key={index}
              className="group relative bg-white rounded-3xl p-8 border border-[#e2e2e2] transition-all duration-300 hover:-translate-y-3 hover:shadow-2xl hover:border-[#2e68ff]"
              style={{
                marginTop: `${testimonial.offset}px`,
                opacity: isVisible ? 1 : 0,
                transform: isVisible ? 'translateY(0)' : 'translateY(60px)',
                transition: `all 0.7s var(--ease-expo-out) ${150 + index * 150}ms`,
              }}
            >
              {/* Quote Icon */}
              <div 
                className="absolute -top-4 -left-2 w-10 h-10 rounded-xl bg-[#2e68ff] flex items-center justify-center transition-all duration-300 group-hover:bg-[#ffba07] group-hover:rotate-12"
                style={{
                  opacity: isVisible ? 1 : 0,
                  transform: isVisible ? 'scale(1) rotate(0)' : 'scale(0) rotate(-20deg)',
                  transition: `all 0.4s var(--ease-spring) ${400 + index * 150}ms`,
                }}
              >
                <Quote className="w-5 h-5 text-white" />
              </div>

              {/* Rating */}
              <div className="flex gap-1 mb-4">
                {[...Array(testimonial.rating)].map((_, i) => (
                  <Star 
                    key={i} 
                    className="w-5 h-5 text-[#ffba07] fill-[#ffba07]"
                    style={{
                      opacity: isVisible ? 1 : 0,
                      transform: isVisible ? 'scale(1)' : 'scale(0)',
                      transition: `all 0.2s var(--ease-elastic) ${600 + i * 100}ms`,
                    }}
                  />
                ))}
              </div>

              {/* Quote */}
              <p className="text-[#666] leading-relaxed mb-6">
                "{testimonial.quote}"
              </p>

              {/* Author */}
              <div className="flex items-center gap-4">
                <div 
                  className="w-14 h-14 rounded-full overflow-hidden border-2 border-[#e2e2e2] transition-all duration-300 group-hover:border-[#2e68ff] group-hover:scale-110"
                  style={{
                    opacity: isVisible ? 1 : 0,
                    transform: isVisible ? 'scale(1)' : 'scale(0)',
                    transition: `all 0.4s var(--ease-spring) 800ms`,
                  }}
                >
                  <img
                    src={testimonial.avatar}
                    alt={testimonial.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <h4 className="font-semibold font-['Poppins'] text-[#333]">
                    {testimonial.name}
                  </h4>
                  <p className="text-sm text-[#999]">
                    {testimonial.role}
                  </p>
                </div>
              </div>

              {/* Decorative corner */}
              <div className="absolute bottom-0 right-0 w-24 h-24 overflow-hidden rounded-br-3xl">
                <div className="absolute bottom-0 right-0 w-32 h-32 bg-gradient-to-tl from-[#2e68ff]/5 to-transparent transform translate-x-8 translate-y-8 group-hover:translate-x-4 group-hover:translate-y-4 transition-transform duration-500" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
