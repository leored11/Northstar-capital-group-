import { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ArrowRight, Sparkles } from 'lucide-react';

const CTA = () => {
  const [email, setEmail] = useState('');
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.3 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert(`Thank you for signing up with: ${email}`);
    setEmail('');
  };

  const titleText = 'Ready to Start Investing?';

  return (
    <section 
      id="cta"
      ref={sectionRef}
      className="py-24 relative overflow-hidden"
    >
      {/* Animated Gradient Background */}
      <div className="absolute inset-0 bg-gradient-primary">
        {/* Animated mesh overlay */}
        <div 
          className="absolute inset-0 opacity-30"
          style={{
            background: `
              radial-gradient(circle at 20% 80%, rgba(255, 186, 7, 0.3) 0%, transparent 50%),
              radial-gradient(circle at 80% 20%, rgba(255, 255, 255, 0.2) 0%, transparent 50%),
              radial-gradient(circle at 50% 50%, rgba(0, 50, 179, 0.4) 0%, transparent 70%)
            `,
            animation: 'gradient-shift 15s ease-in-out infinite',
          }}
        />
        
        {/* Floating particles */}
        {[...Array(15)].map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-white/10"
            style={{
              width: `${Math.random() * 8 + 4}px`,
              height: `${Math.random() * 8 + 4}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `float ${Math.random() * 4 + 6}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 4}s`,
            }}
          />
        ))}
      </div>

      <div className="max-w-[800px] mx-auto px-5 relative z-10 text-center">
        {/* Sparkle Icon */}
        <div 
          className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-white/20 backdrop-blur-sm mb-8"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'scale(1)' : 'scale(0)',
            transition: 'all 0.5s var(--ease-spring) 100ms',
          }}
        >
          <Sparkles className="w-8 h-8 text-white" />
        </div>

        {/* Title with character animation */}
        <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-['Poppins'] text-white mb-6">
          {titleText.split('').map((char, index) => (
            <span
              key={index}
              className="inline-block"
              style={{
                opacity: isVisible ? 1 : 0,
                transform: isVisible ? 'translateY(0)' : 'translateY(50px)',
                transition: `all 0.6s var(--ease-expo-out) ${200 + index * 30}ms`,
              }}
            >
              {char === ' ' ? '\u00A0' : char}
            </span>
          ))}
        </h2>

        {/* Description */}
        <p 
          className="text-lg text-white/80 mb-10 max-w-xl mx-auto"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(30px)',
            transition: 'all 0.5s var(--ease-expo-out) 600ms',
          }}
        >
          Join thousands of investors who trust NorthStar Capital Group for their financial future. Sign up in minutes and start trading today.
        </p>

        {/* Form */}
        <form 
          onSubmit={handleSubmit}
          className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'scale(1)' : 'scale(0.95)',
            transition: 'all 0.5s var(--ease-expo-out) 800ms',
          }}
        >
          <div className="relative flex-1">
            <Input
              type="email"
              placeholder="Enter your email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full h-14 pl-5 pr-4 rounded-full border-2 border-white/30 bg-white/10 backdrop-blur-sm text-white placeholder:text-white/60 focus:border-[#ffba07] focus:ring-4 focus:ring-[#ffba07]/30 transition-all duration-300"
              required
            />
          </div>
          <Button 
            type="submit"
            className="h-14 px-8 bg-[#ffba07] hover:bg-[#e5a800] text-[#333] rounded-full font-semibold transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-[#ffba07]/50 flex items-center gap-2 group animate-pulse-glow"
          >
            Get Started
            <ArrowRight className="w-5 h-5 transition-transform duration-300 group-hover:translate-x-1" />
          </Button>
        </form>

        {/* Trust badges */}
        <div 
          className="flex flex-wrap items-center justify-center gap-6 mt-10"
          style={{
            opacity: isVisible ? 1 : 0,
            transition: 'all 0.5s var(--ease-expo-out) 1000ms',
          }}
        >
          {['No credit card required', 'Free to start', 'Cancel anytime'].map((text, index) => (
            <div key={index} className="flex items-center gap-2 text-white/70 text-sm">
              <svg className="w-5 h-5 text-[#ffba07]" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
              </svg>
              {text}
            </div>
          ))}
        </div>
      </div>

      <style>{`
        @keyframes gradient-shift {
          0%, 100% {
            background-position: 0% 50%;
          }
          50% {
            background-position: 100% 50%;
          }
        }
      `}</style>
    </section>
  );
};

export default CTA;
