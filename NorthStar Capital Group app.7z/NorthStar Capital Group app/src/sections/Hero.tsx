import { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { ArrowRight, TrendingUp } from 'lucide-react';

const Hero = () => {
  const [email, setEmail] = useState('');
  const [isVisible, setIsVisible] = useState(false);
  const heroRef = useRef<HTMLElement>(null);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    alert(`Thank you for signing up with: ${email}`);
    setEmail('');
  };

  const titleWords = ['Invest', 'in', 'the', 'Future,', 'Today'];

  return (
    <section 
      id="hero" 
      ref={heroRef}
      className="relative min-h-screen overflow-hidden bg-gradient-to-br from-white via-[#fafafa] to-[#f0f4ff] pt-32 pb-20"
    >
      {/* Background Particle Effect */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        {[...Array(20)].map((_, i) => (
          <div
            key={i}
            className="absolute rounded-full bg-[#2e68ff]/10"
            style={{
              width: `${Math.random() * 10 + 5}px`,
              height: `${Math.random() * 10 + 5}px`,
              left: `${Math.random() * 100}%`,
              top: `${Math.random() * 100}%`,
              animation: `float ${Math.random() * 4 + 6}s ease-in-out infinite`,
              animationDelay: `${Math.random() * 4}s`,
            }}
          />
        ))}
        {/* Connected lines effect */}
        <svg className="absolute inset-0 w-full h-full opacity-10">
          <defs>
            <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="100%">
              <stop offset="0%" stopColor="#2e68ff" />
              <stop offset="100%" stopColor="#ffba07" />
            </linearGradient>
          </defs>
          {[...Array(5)].map((_, i) => (
            <path
              key={i}
              d={`M ${Math.random() * 500} ${Math.random() * 500} Q ${Math.random() * 800} ${Math.random() * 600} ${Math.random() * 1200} ${Math.random() * 700}`}
              stroke="url(#lineGradient)"
              strokeWidth="1"
              fill="none"
              style={{
                animation: `dash 20s linear infinite`,
                strokeDasharray: '10, 10',
              }}
            />
          ))}
        </svg>
      </div>

      <div className="max-w-[1400px] mx-auto px-5 relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 lg:gap-8 items-center">
          {/* Left Content */}
          <div className="space-y-8">
            {/* Title with word-by-word reveal */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl xl:text-7xl font-bold font-['Poppins'] leading-tight text-[#333]">
              {titleWords.map((word, index) => (
                <span
                  key={index}
                  className="inline-block mr-3"
                  style={{
                    opacity: isVisible ? 1 : 0,
                    transform: isVisible ? 'translateY(0)' : 'translateY(40px)',
                    clipPath: isVisible ? 'inset(0)' : 'inset(100% 0 0 0)',
                    transition: `all 0.8s var(--ease-expo-out) ${200 + index * 100}ms`,
                  }}
                >
                  {word === 'Future,' || word === 'Today' ? (
                    <span className="text-gradient">{word}</span>
                  ) : (
                    word
                  )}
                </span>
              ))}
            </h1>

            {/* Description */}
            <p 
              className="text-lg text-[#666] max-w-xl leading-relaxed"
              style={{
                opacity: isVisible ? 1 : 0,
                transform: isVisible ? 'translateY(0)' : 'translateY(30px)',
                transition: 'all 0.7s var(--ease-expo-out) 700ms',
              }}
            >
              Join over <span className="font-semibold text-[#2e68ff]">20,000 traders</span> who trust NorthStar Capital Group for zero-commission investing. Access stocks, ETFs, options, and crypto—all in one powerful platform.
            </p>

            {/* Email Form */}
            <form 
              onSubmit={handleSubmit}
              className="flex flex-col sm:flex-row gap-3 max-w-md"
              style={{
                opacity: isVisible ? 1 : 0,
                transform: isVisible ? 'scaleX(1)' : 'scaleX(0.8)',
                transition: 'all 0.6s var(--ease-expo-out) 900ms',
              }}
            >
              <div className="relative flex-1">
                <Input
                  type="email"
                  placeholder="Enter your email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full h-14 pl-5 pr-4 rounded-full border-2 border-[#e2e2e2] focus:border-[#2e68ff] focus:ring-4 focus:ring-[#2e68ff]/20 transition-all duration-300 text-[#333] placeholder:text-[#999]"
                  required
                />
              </div>
              <Button 
                type="submit"
                className="h-14 px-8 bg-[#2e68ff] hover:bg-[#0032b3] text-white rounded-full font-semibold transition-all duration-300 hover:scale-105 hover:shadow-xl hover:shadow-[#2e68ff]/30 flex items-center gap-2 group"
              >
                Start Investing
                <ArrowRight className="w-5 h-5 transition-transform duration-300 group-hover:translate-x-1" />
              </Button>
            </form>

            {/* Social Proof */}
            <div 
              className="flex items-center gap-4"
              style={{
                opacity: isVisible ? 1 : 0,
                transform: isVisible ? 'translateX(0)' : 'translateX(-20px)',
                transition: 'all 0.5s var(--ease-expo-out) 1100ms',
              }}
            >
              <div className="flex -space-x-3">
                {['/avatar-1.jpg', '/avatar-2.jpg', '/avatar-3.jpg'].map((avatar, index) => (
                  <div
                    key={index}
                    className="w-12 h-12 rounded-full border-2 border-white overflow-hidden transition-all duration-300 hover:scale-110 hover:z-10 hover:border-[#2e68ff]"
                    style={{
                      opacity: isVisible ? 1 : 0,
                      transform: isVisible ? 'scale(1)' : 'scale(0)',
                      transition: `all 0.4s var(--ease-elastic) ${1100 + index * 100}ms`,
                    }}
                  >
                    <img 
                      src={avatar} 
                      alt={`User ${index + 1}`}
                      className="w-full h-full object-cover"
                    />
                  </div>
                ))}
              </div>
              <div className="flex items-center gap-2">
                <div className="flex items-center gap-1 text-[#ffba07]">
                  {[...Array(5)].map((_, i) => (
                    <TrendingUp key={i} className="w-4 h-4 fill-current" />
                  ))}
                </div>
                <span className="text-sm text-[#666]">
                  <span className="font-semibold text-[#333]">20,000+</span> traders trust InvestHub
                </span>
              </div>
            </div>
          </div>

          {/* Right Content - Hero Images */}
          <div 
            className="relative perspective-1000"
            style={{
              opacity: isVisible ? 1 : 0,
              transform: isVisible ? 'rotateY(-5deg)' : 'rotateY(-25deg)',
              transition: 'all 1.2s var(--ease-expo-out) 400ms',
            }}
          >
            {/* Main Hero Image */}
            <div 
              className="relative animate-float preserve-3d"
              style={{ transformStyle: 'preserve-3d' }}
            >
              <img
                src="/hero-main.jpg"
                alt="InvestHub Mobile App"
                className="w-full max-w-lg mx-auto rounded-3xl shadow-2xl transition-all duration-400 hover:scale-[1.02] hover:rotate-y-0"
                style={{
                  transform: 'rotateY(5deg)',
                }}
              />
              
              {/* Floating Info Card */}
              <div 
                className="absolute -bottom-6 -left-6 w-48 animate-float-delayed"
                style={{
                  opacity: isVisible ? 1 : 0,
                  transform: isVisible ? 'translateY(0) scale(1)' : 'translateY(100px) scale(0.7)',
                  transition: 'all 1s var(--ease-spring) 800ms',
                }}
              >
                <img
                  src="/hero-card.jpg"
                  alt="Growth Stats"
                  className="w-full rounded-2xl shadow-xl"
                />
              </div>

              {/* Stats Badge */}
              <div 
                className="absolute -top-4 -right-4 bg-white rounded-2xl shadow-xl p-4 animate-pulse-glow"
                style={{
                  opacity: isVisible ? 1 : 0,
                  transform: isVisible ? 'translateY(0) scale(1)' : 'translateY(50px) scale(0.8)',
                  transition: 'all 0.8s var(--ease-spring) 1000ms',
                }}
              >
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-xl bg-gradient-primary flex items-center justify-center">
                    <TrendingUp className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-[#333] font-['Poppins']">+24%</p>
                    <p className="text-sm text-[#999]">This Month</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes dash {
          to {
            stroke-dashoffset: -200;
          }
        }
        .hover\:rotate-y-0:hover {
          transform: rotateY(0deg) !important;
        }
      `}</style>
    </section>
  );
};

export default Hero;
