import { useEffect, useRef, useState } from 'react';
import { Calculator as CalcIcon, TrendingUp, DollarSign, Clock, Percent } from 'lucide-react';

const Calculator = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [initialInvestment, setInitialInvestment] = useState(10000);
  const [monthlyContribution, setMonthlyContribution] = useState(500);
  const [annualReturn, setAnnualReturn] = useState(8);
  const [years, setYears] = useState(20);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  // Compound interest calculation
  const calculateReturns = () => {
    const monthlyRate = annualReturn / 100 / 12;
    const totalMonths = years * 12;
    
    let futureValue = initialInvestment * Math.pow(1 + monthlyRate, totalMonths);
    
    if (monthlyContribution > 0) {
      futureValue += monthlyContribution * ((Math.pow(1 + monthlyRate, totalMonths) - 1) / monthlyRate);
    }
    
    const totalContributions = initialInvestment + (monthlyContribution * totalMonths);
    const totalInterest = futureValue - totalContributions;
    
    return {
      futureValue: Math.round(futureValue),
      totalContributions: Math.round(totalContributions),
      totalInterest: Math.round(totalInterest),
    };
  };

  const results = calculateReturns();

  // Generate yearly breakdown for chart
  const yearlyData = [];
  for (let year = 0; year <= years; year++) {
    const monthlyRate = annualReturn / 100 / 12;
    const months = year * 12;
    let value = initialInvestment * Math.pow(1 + monthlyRate, months);
    if (monthlyContribution > 0) {
      value += monthlyContribution * ((Math.pow(1 + monthlyRate, months) - 1) / monthlyRate);
    }
    yearlyData.push({ year, value: Math.round(value) });
  }

  const maxValue = Math.max(...yearlyData.map(d => d.value));

  return (
    <section 
      id="calculator"
      ref={sectionRef}
      className="py-24 bg-white"
    >
      <div className="max-w-[1400px] mx-auto px-5">
        {/* Section Header */}
        <div 
          className="text-center mb-16"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(40px)',
            transition: 'all 0.7s var(--ease-expo-out)',
          }}
        >
          <span className="inline-block px-4 py-2 bg-[#2e68ff]/10 text-[#2e68ff] rounded-full text-sm font-semibold mb-4">
            Investment Tools
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-['Poppins'] text-[#333] mb-4">
            Investment <span className="text-gradient">Calculator</span>
          </h2>
          <p className="text-lg text-[#666] max-w-2xl mx-auto">
            See how much your investments could grow over time
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Calculator Inputs */}
          <div 
            className="bg-[#fafafa] rounded-3xl p-8"
            style={{
              opacity: isVisible ? 1 : 0,
              transform: isVisible ? 'translateX(0)' : 'translateX(-30px)',
              transition: 'all 0.7s var(--ease-expo-out) 200ms',
            }}
          >
            <div className="flex items-center gap-3 mb-8">
              <div className="w-12 h-12 rounded-xl bg-gradient-primary flex items-center justify-center">
                <CalcIcon className="w-6 h-6 text-white" />
              </div>
              <h3 className="text-xl font-bold font-['Poppins'] text-[#333]">Input Your Details</h3>
            </div>

            <div className="space-y-6">
              {/* Initial Investment */}
              <div>
                <label className="flex items-center gap-2 text-sm font-medium text-[#333] mb-2">
                  <DollarSign className="w-4 h-4 text-[#2e68ff]" />
                  Initial Investment
                </label>
                <div className="flex items-center gap-4">
                  <input
                    type="range"
                    min="0"
                    max="100000"
                    step="1000"
                    value={initialInvestment}
                    onChange={(e) => setInitialInvestment(Number(e.target.value))}
                    className="flex-1 h-2 bg-[#e2e2e2] rounded-lg appearance-none cursor-pointer accent-[#2e68ff]"
                  />
                  <div className="w-32 px-4 py-2 bg-white rounded-xl border border-[#e2e2e2] text-right font-semibold text-[#333]">
                    ${initialInvestment.toLocaleString()}
                  </div>
                </div>
              </div>

              {/* Monthly Contribution */}
              <div>
                <label className="flex items-center gap-2 text-sm font-medium text-[#333] mb-2">
                  <TrendingUp className="w-4 h-4 text-[#2e68ff]" />
                  Monthly Contribution
                </label>
                <div className="flex items-center gap-4">
                  <input
                    type="range"
                    min="0"
                    max="5000"
                    step="50"
                    value={monthlyContribution}
                    onChange={(e) => setMonthlyContribution(Number(e.target.value))}
                    className="flex-1 h-2 bg-[#e2e2e2] rounded-lg appearance-none cursor-pointer accent-[#2e68ff]"
                  />
                  <div className="w-32 px-4 py-2 bg-white rounded-xl border border-[#e2e2e2] text-right font-semibold text-[#333]">
                    ${monthlyContribution.toLocaleString()}
                  </div>
                </div>
              </div>

              {/* Annual Return */}
              <div>
                <label className="flex items-center gap-2 text-sm font-medium text-[#333] mb-2">
                  <Percent className="w-4 h-4 text-[#2e68ff]" />
                  Expected Annual Return
                </label>
                <div className="flex items-center gap-4">
                  <input
                    type="range"
                    min="1"
                    max="15"
                    step="0.5"
                    value={annualReturn}
                    onChange={(e) => setAnnualReturn(Number(e.target.value))}
                    className="flex-1 h-2 bg-[#e2e2e2] rounded-lg appearance-none cursor-pointer accent-[#2e68ff]"
                  />
                  <div className="w-32 px-4 py-2 bg-white rounded-xl border border-[#e2e2e2] text-right font-semibold text-[#333]">
                    {annualReturn}%
                  </div>
                </div>
              </div>

              {/* Years */}
              <div>
                <label className="flex items-center gap-2 text-sm font-medium text-[#333] mb-2">
                  <Clock className="w-4 h-4 text-[#2e68ff]" />
                  Investment Period
                </label>
                <div className="flex items-center gap-4">
                  <input
                    type="range"
                    min="1"
                    max="40"
                    step="1"
                    value={years}
                    onChange={(e) => setYears(Number(e.target.value))}
                    className="flex-1 h-2 bg-[#e2e2e2] rounded-lg appearance-none cursor-pointer accent-[#2e68ff]"
                  />
                  <div className="w-32 px-4 py-2 bg-white rounded-xl border border-[#e2e2e2] text-right font-semibold text-[#333]">
                    {years} years
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Results */}
          <div 
            className="space-y-6"
            style={{
              opacity: isVisible ? 1 : 0,
              transform: isVisible ? 'translateX(0)' : 'translateX(30px)',
              transition: 'all 0.7s var(--ease-expo-out) 400ms',
            }}
          >
            {/* Result Cards */}
            <div className="bg-gradient-to-br from-[#2e68ff] to-[#0032b3] rounded-3xl p-8 text-white">
              <p className="text-white/70 text-sm mb-2">Projected Value</p>
              <h3 className="text-4xl lg:text-5xl font-bold font-['Poppins'] mb-6">
                ${results.futureValue.toLocaleString()}
              </h3>
              
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-white/10 rounded-xl p-4">
                  <p className="text-white/70 text-sm mb-1">Total Contributions</p>
                  <p className="text-xl font-semibold">${results.totalContributions.toLocaleString()}</p>
                </div>
                <div className="bg-white/10 rounded-xl p-4">
                  <p className="text-white/70 text-sm mb-1">Interest Earned</p>
                  <p className="text-xl font-semibold text-[#ffba07]">+${results.totalInterest.toLocaleString()}</p>
                </div>
              </div>
            </div>

            {/* Growth Chart */}
            <div className="bg-white rounded-3xl p-6 border border-[#e2e2e2]">
              <h4 className="font-semibold text-[#333] mb-4">Growth Over Time</h4>
              <div className="h-48 relative">
                <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                  <defs>
                    <linearGradient id="growthGradient" x1="0%" y1="0%" x2="0%" y2="100%">
                      <stop offset="0%" stopColor="#2e68ff" stopOpacity="0.3" />
                      <stop offset="100%" stopColor="#2e68ff" stopOpacity="0" />
                    </linearGradient>
                  </defs>
                  
                  {/* Area fill */}
                  <path
                    d={`M 0 ${100 - (yearlyData[0].value / maxValue) * 80} ${yearlyData.map((d, i) => 
                      `L ${(i / (yearlyData.length - 1)) * 100} ${100 - (d.value / maxValue) * 80}`
                    ).join(' ')} L 100 100 L 0 100 Z`}
                    fill="url(#growthGradient)"
                  />
                  
                  {/* Line */}
                  <path
                    d={`M 0 ${100 - (yearlyData[0].value / maxValue) * 80} ${yearlyData.map((d, i) => 
                      `L ${(i / (yearlyData.length - 1)) * 100} ${100 - (d.value / maxValue) * 80}`
                    ).join(' ')}`}
                    fill="none"
                    stroke="#2e68ff"
                    strokeWidth="0.5"
                  />
                </svg>

                {/* X-axis labels */}
                <div className="flex justify-between text-xs text-[#999] mt-2">
                  <span>Year 0</span>
                  <span>Year {Math.floor(years / 2)}</span>
                  <span>Year {years}</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Calculator;
