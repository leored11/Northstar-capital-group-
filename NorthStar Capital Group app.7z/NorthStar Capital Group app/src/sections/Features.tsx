import { useEffect, useRef, useState } from 'react';
import { DollarSign, BarChart3, Shield } from 'lucide-react';

const Features = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const features = [
    {
      icon: DollarSign,
      title: 'Zero Commission',
      description: 'Trade stocks, ETFs, and options with zero commission fees. Keep more of your returns with every trade.',
      offset: 0,
    },
    {
      icon: BarChart3,
      title: 'Advanced Tools',
      description: 'Professional-grade charting, real-time data, and powerful analysis tools at your fingertips.',
      offset: 40,
    },
    {
      icon: Shield,
      title: 'Secure Trading',
      description: 'Bank-level encryption and security protocols protect your investments and personal data 24/7.',
      offset: 20,
    },
  ];

  return (
    <section 
      id="features"
      ref={sectionRef}
      className="py-24 bg-[#fafafa]"
    >
      <div className="max-w-[1400px] mx-auto px-5">
        {/* Section Header */}
        <div 
          className="text-center mb-16"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(40px)',
            transition: 'all 0.7s var(--ease-expo-out)',
          }}
        >
          <span className="inline-block px-4 py-2 bg-[#2e68ff]/10 text-[#2e68ff] rounded-full text-sm font-semibold mb-4">
            Why Choose Us
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-['Poppins'] text-[#333] mb-4">
            Invest with <span className="text-gradient">Confidence</span>
          </h2>
          <p className="text-lg text-[#666] max-w-2xl mx-auto">
            Everything you need to trade smarter, faster, and more securely
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div
                key={index}
                className="group relative bg-white rounded-3xl p-8 border border-[#e2e2e2] transition-all duration-300 hover:-translate-y-3 hover:shadow-2xl hover:shadow-[#2e68ff]/10 hover:border-[#2e68ff]"
                style={{
                  marginTop: `${feature.offset}px`,
                  opacity: isVisible ? 1 : 0,
                  transform: isVisible ? `translateY(0)` : 'translateY(80px)',
                  transition: `all 0.7s var(--ease-expo-out) ${index * 150}ms`,
                }}
              >
                {/* Icon */}
                <div 
                  className="w-16 h-16 rounded-2xl bg-gradient-primary flex items-center justify-center mb-6 transition-all duration-300 group-hover:scale-110 group-hover:rotate-6"
                  style={{
                    opacity: isVisible ? 1 : 0,
                    transform: isVisible ? 'scale(1) rotate(0)' : 'scale(0) rotate(-15deg)',
                    transition: `all 0.5s var(--ease-spring) ${200 + index * 150}ms`,
                  }}
                >
                  <Icon className="w-8 h-8 text-white" />
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold font-['Poppins'] text-[#333] mb-3 group-hover:text-[#2e68ff] transition-colors duration-300">
                  {feature.title}
                </h3>
                <p className="text-[#666] leading-relaxed">
                  {feature.description}
                </p>

                {/* Decorative corner */}
                <div className="absolute top-0 right-0 w-20 h-20 overflow-hidden rounded-tr-3xl">
                  <div className="absolute top-0 right-0 w-32 h-32 bg-gradient-to-bl from-[#2e68ff]/5 to-transparent transform translate-x-16 -translate-y-16 group-hover:translate-x-12 group-hover:-translate-y-12 transition-transform duration-500" />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Features;
