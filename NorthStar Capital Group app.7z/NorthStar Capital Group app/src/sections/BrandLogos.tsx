import { useEffect, useRef, useState } from 'react';

const BrandLogos = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  // Generate placeholder logos using SVG
  const logos = [
    { name: 'TechCorp', color: '#2e68ff' },
    { name: 'FinancePro', color: '#ffba07' },
    { name: 'InvestMax', color: '#10b981' },
    { name: 'TradeFlow', color: '#ef4444' },
    { name: 'WealthHub', color: '#8b5cf6' },
    { name: 'StockWise', color: '#f97316' },
    { name: 'CapitalX', color: '#06b6d4' },
    { name: 'ProfitPal', color: '#ec4899' },
    { name: 'MoneyMind', color: '#84cc16' },
    { name: 'GrowFund', color: '#6366f1' },
  ];

  const LogoSVG = ({ name, color }: { name: string; color: string }) => (
    <div className="flex items-center gap-2 px-6 py-3 grayscale hover:grayscale-0 transition-all duration-300 hover:scale-110 cursor-pointer">
      <div 
        className="w-10 h-10 rounded-lg flex items-center justify-center"
        style={{ backgroundColor: `${color}20` }}
      >
        <span className="text-xl font-bold" style={{ color }}>
          {name.charAt(0)}
        </span>
      </div>
      <span className="text-lg font-semibold text-[#333] whitespace-nowrap">{name}</span>
    </div>
  );

  return (
    <section 
      ref={sectionRef}
      className="py-16 bg-white overflow-hidden"
    >
      <div className="max-w-[1400px] mx-auto px-5 mb-10">
        <p 
          className="text-center text-[#999] text-sm uppercase tracking-widest font-medium"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(20px)',
            transition: 'all 0.6s var(--ease-expo-out)',
          }}
        >
          Trusted by leading financial institutions
        </p>
      </div>

      {/* Row 1 - Scrolls Left */}
      <div 
        className="relative mb-6"
        style={{
          opacity: isVisible ? 1 : 0,
          transform: isVisible ? 'translateY(0)' : 'translateY(30px)',
          transition: 'all 0.6s var(--ease-expo-out) 100ms',
        }}
      >
        {/* Gradient Masks */}
        <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-white to-transparent z-10 pointer-events-none" />
        <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-white to-transparent z-10 pointer-events-none" />
        
        <div className="flex animate-scroll-left">
          {[...logos, ...logos].map((logo, index) => (
            <LogoSVG key={`row1-${index}`} name={logo.name} color={logo.color} />
          ))}
        </div>
      </div>

      {/* Row 2 - Scrolls Right */}
      <div 
        className="relative"
        style={{
          opacity: isVisible ? 1 : 0,
          transform: isVisible ? 'translateY(0)' : 'translateY(30px)',
          transition: 'all 0.6s var(--ease-expo-out) 200ms',
        }}
      >
        {/* Gradient Masks */}
        <div className="absolute left-0 top-0 bottom-0 w-32 bg-gradient-to-r from-white to-transparent z-10 pointer-events-none" />
        <div className="absolute right-0 top-0 bottom-0 w-32 bg-gradient-to-l from-white to-transparent z-10 pointer-events-none" />
        
        <div className="flex animate-scroll-right">
          {[...logos.reverse(), ...logos].map((logo, index) => (
            <LogoSVG key={`row2-${index}`} name={logo.name} color={logo.color} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default BrandLogos;
