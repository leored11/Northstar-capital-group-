import { useEffect, useRef, useState } from 'react';
import { Award, Linkedin, Mail, TrendingUp } from 'lucide-react';

const Leadership = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const achievements = [
    '25+ years in financial services',
    'Former VP at Goldman Sachs',
    'CFA Charterholder',
    'MBA from Wharton School',
  ];

  return (
    <section 
      ref={sectionRef}
      className="py-24 bg-white overflow-hidden"
    >
      <div className="max-w-[1400px] mx-auto px-5">
        {/* Section Header */}
        <div 
          className="text-center mb-16"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(40px)',
            transition: 'all 0.7s var(--ease-expo-out)',
          }}
        >
          <span className="inline-block px-4 py-2 bg-[#2e68ff]/10 text-[#2e68ff] rounded-full text-sm font-semibold mb-4">
            Our Leadership
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-['Poppins'] text-[#333] mb-4">
            Guided by <span className="text-gradient">Experience</span>
          </h2>
          <p className="text-lg text-[#666] max-w-2xl mx-auto">
            Led by industry veterans with decades of Wall Street experience
          </p>
        </div>

        {/* Director Card */}
        <div className="max-w-4xl mx-auto">
          <div 
            className="relative bg-gradient-to-br from-[#fafafa] to-white rounded-3xl p-8 lg:p-12 border border-[#e2e2e2] shadow-xl overflow-hidden"
            style={{
              opacity: isVisible ? 1 : 0,
              transform: isVisible ? 'translateY(0)' : 'translateY(60px)',
              transition: 'all 0.8s var(--ease-expo-out) 200ms',
            }}
          >
            {/* Decorative elements */}
            <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-bl from-[#2e68ff]/5 to-transparent rounded-full transform translate-x-32 -translate-y-32" />
            <div className="absolute bottom-0 left-0 w-48 h-48 bg-gradient-to-tr from-[#ffba07]/5 to-transparent rounded-full transform -translate-x-24 translate-y-24" />

            <div className="relative grid lg:grid-cols-3 gap-8 items-center">
              {/* Photo Area */}
              <div 
                className="lg:col-span-1"
                style={{
                  opacity: isVisible ? 1 : 0,
                  transform: isVisible ? 'scale(1)' : 'scale(0.8)',
                  transition: 'all 0.6s var(--ease-spring) 400ms',
                }}
              >
                <div className="relative mx-auto w-48 h-48 lg:w-56 lg:h-56">
                  {/* Photo frame with gradient border */}
                  <div className="absolute inset-0 rounded-2xl bg-gradient-primary p-1">
                    <div className="w-full h-full rounded-2xl overflow-hidden">
                      <img 
                        src="/director-james-leo.jpg" 
                        alt="James S. Leo - Director"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>
                  
                  {/* Badge */}
                  <div className="absolute -bottom-3 left-1/2 -translate-x-1/2 px-4 py-1.5 bg-[#ffba07] rounded-full">
                    <span className="text-sm font-semibold text-[#333]">Director</span>
                  </div>
                </div>
              </div>

              {/* Info Area */}
              <div className="lg:col-span-2 space-y-6">
                <div
                  style={{
                    opacity: isVisible ? 1 : 0,
                    transform: isVisible ? 'translateX(0)' : 'translateX(30px)',
                    transition: 'all 0.6s var(--ease-expo-out) 500ms',
                  }}
                >
                  <h3 className="text-2xl lg:text-3xl font-bold font-['Poppins'] text-[#333] mb-1">
                    James S. Leo
                  </h3>
                  <p className="text-[#2e68ff] font-medium mb-4">
                    Director, NorthStar Capital Group
                  </p>
                  <p className="text-[#666] leading-relaxed">
                    James brings over 25 years of experience in investment banking and wealth management. 
                    Under his leadership, NorthStar Capital Group has grown to serve over 20,000 clients 
                    with assets exceeding $2.5 billion. His vision of democratizing access to professional-grade 
                    investment tools drives our mission every day.
                  </p>
                </div>

                {/* Achievements */}
                <div 
                  className="grid grid-cols-2 gap-3"
                  style={{
                    opacity: isVisible ? 1 : 0,
                    transform: isVisible ? 'translateY(0)' : 'translateY(20px)',
                    transition: 'all 0.6s var(--ease-expo-out) 600ms',
                  }}
                >
                  {achievements.map((achievement, index) => (
                    <div 
                      key={index}
                      className="flex items-center gap-2"
                    >
                      <div className="w-5 h-5 rounded-full bg-[#2e68ff]/10 flex items-center justify-center flex-shrink-0">
                        <Award className="w-3 h-3 text-[#2e68ff]" />
                      </div>
                      <span className="text-sm text-[#666]">{achievement}</span>
                    </div>
                  ))}
                </div>

                {/* Stats */}
                <div 
                  className="flex flex-wrap gap-6 pt-4"
                  style={{
                    opacity: isVisible ? 1 : 0,
                    transform: isVisible ? 'translateY(0)' : 'translateY(20px)',
                    transition: 'all 0.6s var(--ease-expo-out) 700ms',
                  }}
                >
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 rounded-xl bg-[#2e68ff]/10 flex items-center justify-center">
                      <TrendingUp className="w-5 h-5 text-[#2e68ff]" />
                    </div>
                    <div>
                      <p className="text-xl font-bold text-[#333] font-['Poppins']">$2.5B+</p>
                      <p className="text-xs text-[#999]">Assets Under Management</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <div className="w-10 h-10 rounded-xl bg-[#ffba07]/10 flex items-center justify-center">
                      <span className="text-lg font-bold text-[#ffba07]">25+</span>
                    </div>
                    <div>
                      <p className="text-xl font-bold text-[#333] font-['Poppins']">Years</p>
                      <p className="text-xs text-[#999]">Industry Experience</p>
                    </div>
                  </div>
                </div>

                {/* Social Links */}
                <div 
                  className="flex gap-3 pt-2"
                  style={{
                    opacity: isVisible ? 1 : 0,
                    transform: isVisible ? 'translateY(0)' : 'translateY(20px)',
                    transition: 'all 0.6s var(--ease-expo-out) 800ms',
                  }}
                >
                  <a 
                    href="#" 
                    className="w-10 h-10 rounded-full bg-[#f7f7f7] flex items-center justify-center text-[#333] hover:bg-[#2e68ff] hover:text-white transition-all duration-300 hover:scale-110"
                    aria-label="LinkedIn"
                  >
                    <Linkedin className="w-5 h-5" />
                  </a>
                  <a 
                    href="#" 
                    className="w-10 h-10 rounded-full bg-[#f7f7f7] flex items-center justify-center text-[#333] hover:bg-[#2e68ff] hover:text-white transition-all duration-300 hover:scale-110"
                    aria-label="Email"
                  >
                    <Mail className="w-5 h-5" />
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Leadership;
