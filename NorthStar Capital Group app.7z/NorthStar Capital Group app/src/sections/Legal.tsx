import { useEffect, useRef, useState } from 'react';
import { Shield, FileText, Lock } from 'lucide-react';

const Legal = () => {
  const [isVisible, setIsVisible] = useState(false);
  const [activeTab, setActiveTab] = useState<'terms' | 'privacy'>('terms');
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.1 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const termsContent = [
    {
      title: '1. Acceptance of Terms',
      content: 'By accessing or using NorthStar Capital Group\'s services, you agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our services.',
    },
    {
      title: '2. Account Registration',
      content: 'To use our services, you must create an account and provide accurate, complete information. You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account.',
    },
    {
      title: '3. Investment Risks',
      content: 'All investments involve risk, including the possible loss of principal. Past performance does not guarantee future results. You should carefully consider your investment objectives, level of experience, and risk appetite before investing.',
    },
    {
      title: '4. Commission-Free Trading',
      content: 'NorthStar Capital Group offers commission-free trading for stocks, ETFs, and options. Other fees may apply, including regulatory fees, SEC fees, and fees for additional services.',
    },
    {
      title: '5. Prohibited Activities',
      content: 'You agree not to engage in any unlawful activities, market manipulation, or activities that may harm our platform or other users. We reserve the right to suspend or terminate accounts that violate these terms.',
    },
    {
      title: '6. Intellectual Property',
      content: 'All content, trademarks, and intellectual property on our platform are owned by NorthStar Capital Group. You may not use, reproduce, or distribute our content without written permission.',
    },
  ];

  const privacyContent = [
    {
      title: '1. Information We Collect',
      content: 'We collect personal information you provide (name, email, phone, address), financial information (bank account, investment data), and usage data (IP address, device information, browsing history).',
    },
    {
      title: '2. How We Use Your Information',
      content: 'We use your information to provide and improve our services, process transactions, communicate with you, comply with legal obligations, and protect against fraud and unauthorized access.',
    },
    {
      title: '3. Information Security',
      content: 'We implement industry-standard security measures including encryption, firewalls, and secure data centers. We use bank-level 256-bit SSL encryption to protect your data in transit and at rest.',
    },
    {
      title: '4. Information Sharing',
      content: 'We do not sell your personal information. We may share information with service providers, regulatory authorities when required by law, and in connection with business transfers.',
    },
    {
      title: '5. Your Rights',
      content: 'You have the right to access, correct, or delete your personal information. You may also opt out of marketing communications and request a copy of your data.',
    },
    {
      title: '6. Cookies and Tracking',
      content: 'We use cookies and similar technologies to enhance your experience, analyze usage patterns, and deliver personalized content. You can manage cookie preferences through your browser settings.',
    },
  ];

  const currentContent = activeTab === 'terms' ? termsContent : privacyContent;

  return (
    <section 
      id="legal"
      ref={sectionRef}
      className="py-24 bg-white"
    >
      <div className="max-w-[1000px] mx-auto px-5">
        {/* Section Header */}
        <div 
          className="text-center mb-12"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(40px)',
            transition: 'all 0.7s var(--ease-expo-out)',
          }}
        >
          <span className="inline-block px-4 py-2 bg-[#2e68ff]/10 text-[#2e68ff] rounded-full text-sm font-semibold mb-4">
            Legal
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-['Poppins'] text-[#333] mb-4">
            Terms & <span className="text-gradient">Privacy</span>
          </h2>
          <p className="text-lg text-[#666]">
            Transparency in how we operate and protect your data
          </p>
        </div>

        {/* Tab Navigation */}
        <div 
          className="flex justify-center gap-4 mb-10"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(20px)',
            transition: 'all 0.6s var(--ease-expo-out) 200ms',
          }}
        >
          <button
            onClick={() => setActiveTab('terms')}
            className={`flex items-center gap-2 px-6 py-3 rounded-full font-medium transition-all duration-300 ${
              activeTab === 'terms'
                ? 'bg-[#2e68ff] text-white'
                : 'bg-[#f7f7f7] text-[#666] hover:bg-[#e2e2e2]'
            }`}
          >
            <FileText className="w-5 h-5" />
            Terms of Service
          </button>
          <button
            onClick={() => setActiveTab('privacy')}
            className={`flex items-center gap-2 px-6 py-3 rounded-full font-medium transition-all duration-300 ${
              activeTab === 'privacy'
                ? 'bg-[#2e68ff] text-white'
                : 'bg-[#f7f7f7] text-[#666] hover:bg-[#e2e2e2]'
            }`}
          >
            <Shield className="w-5 h-5" />
            Privacy Policy
          </button>
        </div>

        {/* Content */}
        <div 
          className="bg-[#fafafa] rounded-3xl p-8"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(20px)',
            transition: 'all 0.6s var(--ease-expo-out) 400ms',
          }}
        >
          <div className="flex items-center gap-3 mb-8">
            <div className="w-12 h-12 rounded-xl bg-gradient-primary flex items-center justify-center">
              {activeTab === 'terms' ? (
                <FileText className="w-6 h-6 text-white" />
              ) : (
                <Lock className="w-6 h-6 text-white" />
              )}
            </div>
            <div>
              <h3 className="text-xl font-bold font-['Poppins'] text-[#333]">
                {activeTab === 'terms' ? 'Terms of Service' : 'Privacy Policy'}
              </h3>
              <p className="text-sm text-[#999]">Last updated: February 2024</p>
            </div>
          </div>

          <div className="space-y-6">
            {currentContent.map((item, index) => (
              <div 
                key={index}
                className="bg-white rounded-xl p-6 border border-[#e2e2e2]"
              >
                <h4 className="font-semibold text-[#333] mb-2">{item.title}</h4>
                <p className="text-[#666] leading-relaxed">{item.content}</p>
              </div>
            ))}
          </div>

          <div className="mt-8 p-6 bg-gradient-to-r from-[#2e68ff]/5 to-[#ffba07]/5 rounded-xl">
            <p className="text-sm text-[#666] text-center">
              Have questions about our terms or privacy practices?{' '}
              <a href="#contact" className="text-[#2e68ff] font-semibold hover:underline">
                Contact our support team
              </a>
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Legal;
