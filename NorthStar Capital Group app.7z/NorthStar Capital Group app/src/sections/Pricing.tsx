import { useEffect, useRef, useState } from 'react';
import { Button } from '@/components/ui/button';
import { Check, Sparkles } from 'lucide-react';

const Pricing = () => {
  const [isVisible, setIsVisible] = useState(false);
  const sectionRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsVisible(true);
          observer.disconnect();
        }
      },
      { threshold: 0.2 }
    );

    if (sectionRef.current) {
      observer.observe(sectionRef.current);
    }

    return () => observer.disconnect();
  }, []);

  const plans = [
    {
      name: 'Basic',
      price: '0',
      period: '/month',
      description: 'Perfect for getting started',
      features: [
        'Commission-free trading',
        'Basic charting tools',
        'Market news & updates',
        'Mobile app access',
        'Email support',
      ],
      cta: 'Get Started',
      popular: false,
    },
    {
      name: 'Pro',
      price: '9',
      period: '/month',
      description: 'For serious investors',
      features: [
        'Everything in Basic',
        'Advanced charting',
        'Real-time market data',
        'Priority support',
        'Options trading',
        'Extended hours trading',
      ],
      cta: 'Start Pro Trial',
      popular: true,
    },
    {
      name: 'Premium',
      price: '29',
      period: '/month',
      description: 'Full professional suite',
      features: [
        'Everything in Pro',
        'Advanced options strategies',
        'Margin account',
        'Dedicated advisor',
        'Tax optimization',
        'API access',
      ],
      cta: 'Go Premium',
      popular: false,
    },
  ];

  return (
    <section 
      id="pricing"
      ref={sectionRef}
      className="py-24 bg-white"
    >
      <div className="max-w-[1400px] mx-auto px-5">
        {/* Section Header */}
        <div 
          className="text-center mb-16"
          style={{
            opacity: isVisible ? 1 : 0,
            transform: isVisible ? 'translateY(0)' : 'translateY(40px)',
            transition: 'all 0.7s var(--ease-expo-out)',
          }}
        >
          <span className="inline-block px-4 py-2 bg-[#2e68ff]/10 text-[#2e68ff] rounded-full text-sm font-semibold mb-4">
            Pricing Plans
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold font-['Poppins'] text-[#333] mb-4">
            Simple, <span className="text-gradient">Transparent</span> Pricing
          </h2>
          <p className="text-lg text-[#666] max-w-2xl mx-auto">
            Choose the plan that fits your investment goals. No hidden fees, ever.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid md:grid-cols-3 gap-8 perspective-1000">
          {plans.map((plan, index) => (
            <div
              key={index}
              className={`relative rounded-3xl p-8 transition-all duration-400 hover:-translate-y-4 preserve-3d ${
                plan.popular
                  ? 'bg-gradient-to-br from-[#2e68ff] to-[#0032b3] text-white scale-105 shadow-2xl shadow-[#2e68ff]/30 border-2 border-[#ffba07]'
                  : 'bg-white border-2 border-[#e2e2e2] hover:border-[#2e68ff] hover:shadow-2xl'
              }`}
              style={{
                opacity: isVisible ? 1 : 0,
                transform: isVisible 
                  ? plan.popular ? 'scale(1.05) rotateY(0)' : 'rotateY(0)' 
                  : 'rotateY(-90deg)',
                transition: `all 0.8s var(--ease-expo-out) ${200 + index * 150}ms`,
              }}
            >
              {/* Popular Badge */}
              {plan.popular && (
                <div className="absolute -top-4 left-1/2 -translate-x-1/2">
                  <div className="flex items-center gap-1 px-4 py-1.5 bg-[#ffba07] rounded-full text-sm font-semibold text-[#333]">
                    <Sparkles className="w-4 h-4" />
                    Most Popular
                  </div>
                </div>
              )}

              {/* Plan Name */}
              <h3 className={`text-xl font-bold font-['Poppins'] mb-2 ${
                plan.popular ? 'text-white' : 'text-[#333]'
              }`}>
                {plan.name}
              </h3>
              
              <p className={`text-sm mb-6 ${
                plan.popular ? 'text-white/70' : 'text-[#666]'
              }`}>
                {plan.description}
              </p>

              {/* Price */}
              <div className="mb-8">
                <span className={`text-5xl font-bold font-['Poppins'] ${
                  plan.popular ? 'text-white' : 'text-[#333]'
                }`}>
                  ${plan.price}
                </span>
                <span className={plan.popular ? 'text-white/70' : 'text-[#666]'}>
                  {plan.period}
                </span>
              </div>

              {/* Features */}
              <ul className="space-y-4 mb-8">
                {plan.features.map((feature, featureIndex) => (
                  <li 
                    key={featureIndex}
                    className="flex items-start gap-3"
                    style={{
                      opacity: isVisible ? 1 : 0,
                      transform: isVisible ? 'translateY(0)' : 'translateY(10px)',
                      transition: `all 0.3s var(--ease-expo-out) ${800 + featureIndex * 100}ms`,
                    }}
                  >
                    <div className={`w-5 h-5 rounded-full flex items-center justify-center flex-shrink-0 mt-0.5 ${
                      plan.popular ? 'bg-[#ffba07]' : 'bg-[#2e68ff]'
                    }`}>
                      <Check className="w-3 h-3 text-white" strokeWidth={3} />
                    </div>
                    <span className={plan.popular ? 'text-white/90' : 'text-[#666]'}>
                      {feature}
                    </span>
                  </li>
                ))}
              </ul>

              {/* CTA Button */}
              <Button 
                className={`w-full py-3 rounded-full font-semibold transition-all duration-300 hover:scale-105 ${
                  plan.popular
                    ? 'bg-[#ffba07] hover:bg-[#e5a800] text-[#333]'
                    : 'bg-[#2e68ff] hover:bg-[#0032b3] text-white'
                }`}
                style={{
                  opacity: isVisible ? 1 : 0,
                  transform: isVisible ? 'scale(1)' : 'scale(0.9)',
                  transition: `all 0.4s var(--ease-spring) 1000ms`,
                }}
              >
                {plan.cta}
              </Button>
            </div>
          ))}
        </div>

        {/* Money back guarantee */}
        <p 
          className="text-center text-[#999] mt-10"
          style={{
            opacity: isVisible ? 1 : 0,
            transition: 'all 0.5s var(--ease-expo-out) 1200ms',
          }}
        >
          30-day money-back guarantee. No questions asked.
        </p>
      </div>
    </section>
  );
};

export default Pricing;
