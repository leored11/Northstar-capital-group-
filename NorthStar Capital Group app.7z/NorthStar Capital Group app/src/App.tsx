import Header from './sections/Header';
import Hero from './sections/Hero';
import BrandLogos from './sections/BrandLogos';
import Features from './sections/Features';
import About from './sections/About';
import Leadership from './sections/Leadership';
import Team from './sections/Team';
import HowToInvest from './sections/HowToInvest';
import InvestmentDashboard from './sections/InvestmentDashboard';
import Calculator from './sections/Calculator';
import Products from './sections/Products';
import Blog from './sections/Blog';
import CTA from './sections/CTA';
import Pricing from './sections/Pricing';
import Testimonials from './sections/Testimonials';
import Careers from './sections/Careers';
import FAQ from './sections/FAQ';
import Contact from './sections/Contact';
import Legal from './sections/Legal';
import Footer from './sections/Footer';

function App() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <main>
        <Hero />
        <BrandLogos />
        <Features />
        <About />
        <Leadership />
        <Team />
        <HowToInvest />
        <InvestmentDashboard />
        <Calculator />
        <Products />
        <Blog />
        <CTA />
        <Pricing />
        <Testimonials />
        <Careers />
        <FAQ />
        <Contact />
        <Legal />
      </main>
      <Footer />
    </div>
  );
}

export default App;
